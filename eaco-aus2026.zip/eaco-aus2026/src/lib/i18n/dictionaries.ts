import type { Language } from './translations';
import { translations } from './translations';

export type Dictionary = typeof translations;

export async function getDictionary(lang: Language): Promise<Dictionary> {
  // In a real app, this could fetch from a CMS or file system
  // For now, we return the static translations
  return translations;
}

export function createTranslator(lang: Language) {
  return (key: keyof Dictionary): string => {
    return translations[key]?.[lang] || key;
  };
}
