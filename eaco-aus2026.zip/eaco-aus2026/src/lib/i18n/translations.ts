// EACO Website Translations - Chinese & English

export const translations = {
  // Navigation
  'nav.home': { zh: '首页', en: 'Home' },
  'nav.about': { zh: '关于我们', en: 'About EACO' },
  'nav.handbook': { zh: '训练手册', en: 'Handbook' },
  'nav.faq': { zh: '常见问题', en: 'FAQ' },
  'nav.investment': { zh: '投资方案', en: 'Investment' },
  'nav.expansion': { zh: '全球扩展', en: 'Global Expansion' },
  'nav.web3': { zh: 'WEB3分析', en: 'WEB3 Analysis' },
  'nav.contact': { zh: '联系我们', en: 'Contact' },

  // Hero Section
  'hero.title': { 
    zh: '澳大利亚 EACO 社区', 
    en: 'Australia EACO Community' 
  },
  'hero.subtitle': { 
    zh: '共创未来 - 创新、协作、成长', 
    en: 'Building the Future Together - Innovation, Collaboration, Growth' 
  },
  'hero.description': { 
    zh: 'EACO是一个致力于连接创新者、建设者和梦想家的全球性社区组织。我们在澳大利亚建立城市节点，培养下一代领导者。',
    en: 'EACO is a global community organization dedicated to connecting innovators, builders, and dreamers. We establish urban nodes in Australia and nurture the next generation of leaders.' 
  },
  'hero.cta.primary': { zh: '立即加入', en: 'Join Now' },
  'hero.cta.secondary': { zh: '了解更多', en: 'Learn More' },

  // Stats
  'stats.members': { zh: '活跃成员', en: 'Active Members' },
  'stats.nodes': { zh: '城市节点', en: 'Urban Nodes' },
  'stats.countries': { zh: '覆盖国家', en: 'Countries' },
  'stats.events': { zh: '举办活动', en: 'Events Hosted' },

  // About Section
  'about.title': { zh: '关于 EACO', en: 'About EACO' },
  'about.mission.title': { zh: '我们的使命', en: 'Our Mission' },
  'about.mission.desc': { 
    zh: '创建一个连接全球创新者的网络，通过教育、协作和资源共享，共同推动社会进步。',
    en: 'To create a network connecting global innovators, promoting social progress through education, collaboration, and resource sharing.' 
  },
  'about.vision.title': { zh: '我们的愿景', en: 'Our Vision' },
  'about.vision.desc': { 
    zh: '成为全球最具影响力的创新社区网络，在每个主要城市建立活跃的EACO节点。',
    en: 'To become the most influential innovation community network globally, establishing active EACO nodes in every major city.' 
  },
  'about.values.title': { zh: '核心价值观', en: 'Core Values' },
  'about.values.innovation': { zh: '创新', en: 'Innovation' },
  'about.values.collaboration': { zh: '协作', en: 'Collaboration' },
  'about.values.growth': { zh: '成长', en: 'Growth' },
  'about.values.integrity': { zh: '诚信', en: 'Integrity' },

  // Handbook Section
  'handbook.title': { zh: '训练手册', en: 'Training Manuals' },
  'handbook.leader.title': { 
    zh: '城市节点 Leader 训练手册', 
    en: 'Urban Node Leader Training Handbook' 
  },
  'handbook.leader.desc': { 
    zh: '专为城市节点负责人设计的全面指南，涵盖领导力发展、团队管理和目标实现。',
    en: 'Comprehensive guide designed for urban node leaders, covering leadership development, team management, and goal achievement.' 
  },
  'handbook.onboarding.title': { 
    zh: '志愿者 Onboarding 套件', 
    en: 'Volunteer Onboarding Kit' 
  },
  'handbook.onboarding.desc': { 
    zh: '新志愿者入门指南，包含欢迎信、起步指南和第一周任务清单。',
    en: 'New volunteer onboarding guide with welcome message, getting started guide, and first week checklist.' 
  },
  'handbook.growth.title': { 
    zh: '1-6个月成长体系', 
    en: '1-6 Month Growth System' 
  },
  'handbook.growth.desc': { 
    zh: '系统化的志愿者成长路径，从入门到成为核心成员的完整发展计划。',
    en: 'Systematic volunteer growth path, complete development plan from entry to becoming a core member.' 
  },
  'handbook.ops.title': { 
    zh: '运营指南（全球可复制）', 
    en: 'Operations Guide (Globally Replicable)' 
  },
  'handbook.ops.desc': { 
    zh: '标准化的运营流程和最佳实践，确保全球各地节点的一致性和高质量。',
    en: 'Standardized operating procedures and best practices ensuring consistency and quality across all nodes worldwide.' 
  },

  // FAQ Section
  'faq.title': { zh: '常见问题', en: 'Frequently Asked Questions' },
  'faq.subtitle': { 
    zh: '关于 EACO 的一切，这里都有答案', 
    en: 'All your EACO questions answered here' 
  },
  'faq.search.placeholder': { zh: '搜索问题...', en: 'Search questions...' },
  'faq.categories.all': { zh: '全部', en: 'All' },
  'faq.categories.about': { zh: '关于EACO', en: 'About EACO' },
  'faq.categories.membership': { zh: '会员相关', en: 'Membership' },
  'faq.categories.web3': { zh: 'WEB3相关', en: 'WEB3' },
  'faq.categories.investment': { zh: '投资相关', en: 'Investment' },
  'faq.categories.expansion': { zh: '扩展相关', en: 'Expansion' },

  // Investment Section
  'investment.title': { zh: '投资方案', en: 'Investment Plans' },
  'investment.subtitle': { 
    zh: '选择适合您的投资级别，开启您的EACO之旅', 
    en: 'Choose your investment level and start your EACO journey' 
  },
  'investment.starter.name': { zh: '起步计划', en: 'Starter Plan' },
  'investment.starter.amount': { zh: '5,000 AUD', en: '5,000 AUD' },
  'investment.starter.period': { zh: '12个月', en: '12 Months' },
  'investment.professional.name': { zh: '专业计划', en: 'Professional Plan' },
  'investment.professional.amount': { zh: '50,000 AUD', en: '50,000 AUD' },
  'investment.professional.period': { zh: '24个月', en: '24 Months' },
  'investment.enterprise.name': { zh: '企业计划', en: 'Enterprise Plan' },
  'investment.enterprise.amount': { zh: '定制方案', en: 'Custom Plan' },
  'investment.enterprise.period': { zh: '长期合作', en: 'Long-term Partnership' },
  'investment.cta': { zh: '立即咨询', en: 'Contact Now' },
  'investment.featured': { zh: '最受欢迎', en: 'Most Popular' },

  // Expansion Section
  'expansion.title': { zh: '全球扩展计划', en: 'Global Expansion Plan' },
  'expansion.subtitle': { 
    zh: '从澳大利亚出发，连接全球友好国家', 
    en: 'Starting from Australia, connecting friendly nations worldwide' 
  },
  'expansion.timeline.title': { zh: '300天执行计划', en: '300-Day Execution Plan' },
  'expansion.timeline.phase1': { zh: '第一阶段（1-100天）', en: 'Phase 1 (Days 1-100)' },
  'expansion.timeline.phase2': { zh: '第二阶段（101-200天）', en: 'Phase 2 (Days 101-200)' },
  'expansion.timeline.phase3': { zh: '第三阶段（201-300天）', en: 'Phase 3 (Days 201-300)' },

  // WEB3 Section
  'web3.title': { zh: 'WEB3与区块链分析', en: 'WEB3 & Blockchain Analysis' },
  'web3.subtitle': { 
    zh: '深入了解澳大利亚及全球WEB3发展趋势', 
    en: 'In-depth analysis of WEB3 trends in Australia and globally' 
  },
  'web3.australia.title': { zh: '澳大利亚WEB3态度', en: 'Australia WEB3 Stance' },
  'web3.regulatory.title': { zh: '监管环境', en: 'Regulatory Environment' },
  'web3.opportunities.title': { zh: '市场机会', en: 'Market Opportunities' },
  'web3.risks.title': { zh: '风险评估', en: 'Risk Assessment' },

  // Friendly Countries
  'friendly.title': { zh: '澳大利亚最友好的10个国家', en: 'Top 10 Australia-Friendly Countries' },
  'friendly.subtitle': { 
    zh: '深入分析各国与澳大利亚的关系及WEB3态度', 
    en: 'In-depth analysis of relationships and WEB3 stance' 
  },

  // Revenue Models
  'revenue.title': { zh: '盈利模式', en: 'Revenue Models' },
  'revenue.subtitle': { 
    zh: '多元化、可续持的收入来源', 
    en: 'Diversified and sustainable revenue sources' 
  },
  'revenue.membership': { zh: '会员费', en: 'Membership Fees' },
  'revenue.training': { zh: '培训项目', en: 'Training Programs' },
  'revenue.consulting': { zh: '咨询服务', en: 'Consulting Services' },
  'revenue.partnership': { zh: '合作项目', en: 'Partnership Programs' },
  'revenue.events': { zh: '活动组织', en: 'Event Organization' },
  'revenue.products': { zh: '数字产品', en: 'Digital Products' },
  'revenue.licensing': { zh: '区域授权', en: 'Regional Licensing' },

  // Contact
  'contact.title': { zh: '联系我们', en: 'Contact Us' },
  'contact.email': { zh: '电子邮件', en: 'Email' },
  'contact.phone': { zh: '电话', en: 'Phone' },
  'contact.address': { zh: '地址', en: 'Address' },
  'contact.form.name': { zh: '您的姓名', en: 'Your Name' },
  'contact.form.email': { zh: '电子邮箱', en: 'Email Address' },
  'contact.form.subject': { zh: '主题', en: 'Subject' },
  'contact.form.message': { zh: '留言内容', en: 'Message' },
  'contact.form.submit': { zh: '发送消息', en: 'Send Message' },

  // Footer
  'footer.tagline': { 
    zh: '连接创新者，共创美好未来', 
    en: 'Connecting Innovators, Building a Better Future' 
  },
  'footer.copyright': { zh: '© 2025 EACO Australia. 保留所有权利。', en: '© 2025 EACO Australia. All rights reserved.' },
  'footer.privacy': { zh: '隐私政策', en: 'Privacy Policy' },
  'footer.terms': { zh: '服务条款', en: 'Terms of Service' },

  // Common
  'common.loading': { zh: '加载中...', en: 'Loading...' },
  'common.error': { zh: '发生错误', en: 'An error occurred' },
  'common.success': { zh: '操作成功', en: 'Operation successful' },
  'common.readmore': { zh: '阅读更多', en: 'Read More' },
  'common.viewall': { zh: '查看全部', en: 'View All' },
  'common.back': { zh: '返回', en: 'Back' },
  'common.next': { zh: '下一个', en: 'Next' },
  'common.previous': { zh: '上一个', en: 'Previous' },
  'common.features': { zh: '功能特点', en: 'Features' },
  'common.benefits': { zh: '优势', en: 'Benefits' },
  'common.requirements': { zh: '要求', en: 'Requirements' },
  'common.included': { zh: '包含内容', en: 'Included' },
};

export type TranslationKey = keyof typeof translations;
export type Language = 'zh' | 'en';

export function getTranslation(key: TranslationKey, lang: Language): string {
  return translations[key]?.[lang] || key;
}
