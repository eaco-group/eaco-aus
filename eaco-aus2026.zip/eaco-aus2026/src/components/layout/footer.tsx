import Link from 'next/link';
import type { Language } from '@/lib/i18n/translations';

interface FooterProps {
  lang: Language;
  dictionary: {
    [key: string]: { zh: string; en: string };
  };
}

const footerLinks = [
  { key: 'about', href: '/about' },
  { key: 'handbook', href: '/handbook' },
  { key: 'faq', href: '/faq' },
  { key: 'investment', href: '/investment' },
  { key: 'expansion', href: '/expansion' },
  { key: 'web3', href: '/web3' },
];

export function Footer({ lang, dictionary }: FooterProps) {
  const getLabel = (key: string) => {
    const navKey = `nav.${key}` as keyof typeof dictionary;
    return dictionary[navKey]?.[lang] || key;
  };

  return (
    <footer className="border-t bg-background">
      <div className="container py-12">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          {/* Brand */}
          <div className="space-y-4">
            <div className="flex items-center space-x-2">
              <div className="h-8 w-8 rounded-lg bg-gradient-to-br from-primary to-teal-500 flex items-center justify-center">
                <span className="text-white font-bold text-lg">E</span>
              </div>
              <span className="font-bold text-xl">EACO</span>
            </div>
            <p className="text-sm text-muted-foreground">
              {dictionary['footer.tagline']?.[lang]}
            </p>
          </div>

          {/* Quick Links */}
          <div>
            <h3 className="font-semibold mb-4">
              {lang === 'zh' ? '快速链接' : 'Quick Links'}
            </h3>
            <ul className="space-y-2">
              {footerLinks.slice(0, 4).map((link) => (
                <li key={link.key}>
                  <Link
                    href={`/${lang}${link.href}`}
                    className="text-sm text-muted-foreground hover:text-primary transition-colors"
                  >
                    {getLabel(link.key)}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          {/* Resources */}
          <div>
            <h3 className="font-semibold mb-4">
              {lang === 'zh' ? '资源' : 'Resources'}
            </h3>
            <ul className="space-y-2">
              {footerLinks.slice(4).map((link) => (
                <li key={link.key}>
                  <Link
                    href={`/${lang}${link.href}`}
                    className="text-sm text-muted-foreground hover:text-primary transition-colors"
                  >
                    {getLabel(link.key)}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          {/* Contact */}
          <div>
            <h3 className="font-semibold mb-4">
              {dictionary['contact.title']?.[lang]}
            </h3>
            <div className="space-y-2 text-sm text-muted-foreground">
              <p>Australia</p>
              <p>contact@eaco-australia.com</p>
              <p>+61 2 1234 5678</p>
            </div>
          </div>
        </div>

        {/* Bottom Bar */}
        <div className="mt-8 pt-8 border-t">
          <div className="flex flex-col md:flex-row justify-between items-center space-y-4 md:space-y-0">
            <p className="text-sm text-muted-foreground">
              {dictionary['footer.copyright']?.[lang]}
            </p>
            <div className="flex space-x-6">
              <Link
                href={`/${lang}/privacy`}
                className="text-sm text-muted-foreground hover:text-primary transition-colors"
              >
                {dictionary['footer.privacy']?.[lang]}
              </Link>
              <Link
                href={`/${lang}/terms`}
                className="text-sm text-muted-foreground hover:text-primary transition-colors"
              >
                {dictionary['footer.terms']?.[lang]}
              </Link>
            </div>
          </div>
        </div>
      </div>
    </footer>
  );
}
