'use client';

import { usePathname, useRouter } from 'next/navigation';
import { useEffect, useState } from 'react';
import type { Language } from '@/lib/i18n/translations';
import { getLangFromPathname } from '@/hooks/use-language';

interface LanguageProviderProps {
  children: React.ReactNode;
  lang: Language;
}

export function LanguageProvider({ children, lang }: LanguageProviderProps) {
  const router = useRouter();
  const pathname = usePathname();
  const [mounted, setMounted] = useState(false);

  useEffect(() => {
    setMounted(true);
    // Validate current path matches language
    const pathLang = getLangFromPathname(pathname);
    if (pathLang !== lang) {
      // Redirect to correct language path if needed
      const correctPath = pathname.replace(/^\/(en|zh)/, `/${lang}`);
      if (correctPath !== pathname) {
        router.replace(correctPath);
      }
    }
  }, [pathname, lang, router]);

  // Prevent hydration mismatch by not rendering until mounted
  if (!mounted) {
    return null;
  }

  return <>{children}</>;
}
