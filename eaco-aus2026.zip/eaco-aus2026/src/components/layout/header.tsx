'use client';

import Link from 'next/link';
import { usePathname } from 'next/navigation';
import { Menu, X, Globe } from 'lucide-react';
import { useState } from 'react';
import { Button } from '@/components/ui/button';
import {
  Sheet,
  SheetContent,
  SheetTrigger,
} from '@/components/ui/sheet';
import { cn } from '@/lib/utils';
import { useLanguage } from '@/hooks/use-language';
import type { Language } from '@/lib/i18n/translations';

interface HeaderProps {
  lang: Language;
  dictionary: {
    [key: string]: { zh: string; en: string };
  };
}

const navItems = [
  { key: 'home', href: '' },
  { key: 'about', href: '/about' },
  { key: 'handbook', href: '/handbook' },
  { key: 'faq', href: '/faq' },
  { key: 'investment', href: '/investment' },
  { key: 'expansion', href: '/expansion' },
  { key: 'web3', href: '/web3' },
];

export function Header({ lang, dictionary }: HeaderProps) {
  const [isOpen, setIsOpen] = useState(false);
  const pathname = usePathname();
  const { switchLanguage } = useLanguage();

  const getNavLabel = (key: string) => {
    const navKey = `nav.${key}` as keyof typeof dictionary;
    return dictionary[navKey]?.[lang] || key;
  };

  const isActive = (href: string) => {
    const fullPath = `/${lang}${href}`;
    return pathname === fullPath || pathname.startsWith(fullPath + '/');
  };

  return (
    <header className="sticky top-0 z-50 w-full border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
      <div className="container flex h-16 items-center justify-between">
        {/* Logo */}
        <Link href={`/${lang}`} className="flex items-center space-x-2">
          <div className="h-8 w-8 rounded-lg bg-gradient-to-br from-primary to-teal-500 flex items-center justify-center">
            <span className="text-white font-bold text-lg">E</span>
          </div>
          <span className="font-bold text-xl">EACO</span>
        </Link>

        {/* Desktop Navigation */}
        <nav className="hidden md:flex items-center space-x-1">
          {navItems.map((item) => (
            <Link
              key={item.key}
              href={`/${lang}${item.href}`}
              className={cn(
                "px-4 py-2 text-sm font-medium rounded-md transition-colors hover:bg-accent",
                isActive(item.href) ? "bg-accent text-accent-foreground" : "text-muted-foreground"
              )}
            >
              {getNavLabel(item.key)}
            </Link>
          ))}
        </nav>

        {/* Language Switcher & Mobile Menu */}
        <div className="flex items-center space-x-2">
          {/* Language Switcher */}
          <Button
            variant="ghost"
            size="sm"
            onClick={() => switchLanguage(lang === 'zh' ? 'en' : 'zh')}
            className="flex items-center space-x-1"
          >
            <Globe className="h-4 w-4" />
            <span className="text-xs">{lang === 'zh' ? 'EN' : '中文'}</span>
          </Button>

          {/* Mobile Menu */}
          <Sheet open={isOpen} onOpenChange={setIsOpen}>
            <SheetTrigger asChild className="md:hidden">
              <Button variant="ghost" size="icon">
                <Menu className="h-5 w-5" />
                <span className="sr-only">Toggle menu</span>
              </Button>
            </SheetTrigger>
            <SheetContent side="right" className="w-[300px]">
              <nav className="flex flex-col space-y-4 mt-8">
                {navItems.map((item) => (
                  <Link
                    key={item.key}
                    href={`/${lang}${item.href}`}
                    onClick={() => setIsOpen(false)}
                    className={cn(
                      "px-4 py-3 text-lg font-medium rounded-lg transition-colors",
                      isActive(item.href) 
                        ? "bg-accent text-accent-foreground" 
                        : "text-muted-foreground hover:bg-accent"
                    )}
                  >
                    {getNavLabel(item.key)}
                  </Link>
                ))}
              </nav>
            </SheetContent>
          </Sheet>
        </div>
      </div>
    </header>
  );
}
