import type { Metadata } from 'next';
import { Inspector } from 'react-dev-inspector';
import './globals.css';

export const metadata: Metadata = {
  title: {
    default: 'Australia EACO Community',
    template: '%s | EACO Australia',
  },
  description:
    'Official website of EACO Australia Community - Connecting Innovators, Building a Better Future',
  keywords: [
    'EACO',
    'Australia',
    'Innovation Community',
    'WEB3',
    'Blockchain',
    'Volunteer',
    'EACO Australia',
  ],
  authors: [{ name: 'EACO Australia', url: process.env.COZE_PROJECT_DOMAIN_DEFAULT }],
  generator: 'Coze Code',
  openGraph: {
    title: 'Australia EACO Community',
    description:
      'Connecting Innovators, Building a Better Future',
    url: process.env.COZE_PROJECT_DOMAIN_DEFAULT,
    siteName: 'EACO Australia',
    locale: 'en_US',
    type: 'website',
  },
  robots: {
    index: true,
    follow: true,
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  const isDev = process.env.COZE_PROJECT_ENV === 'DEV';

  return (
    <html lang="en">
      <body className={`antialiased`}>
        {isDev && <Inspector />}
        {children}
      </body>
    </html>
  );
}
