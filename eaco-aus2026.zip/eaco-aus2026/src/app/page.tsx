import { redirect } from 'next/navigation';
import { cookies, headers } from 'next/headers';

export default async function RootPage() {
  // Try to detect user's preferred language from headers or cookies
  const headersList = await headers();
  const cookieStore = await cookies();
  
  // Check cookie first
  const langCookie = cookieStore.get('NEXT_LANG')?.value;
  if (langCookie === 'zh' || langCookie === 'en') {
    redirect(`/${langCookie}`);
  }
  
  // Check Accept-Language header
  const acceptLanguage = headersList.get('accept-language');
  if (acceptLanguage?.includes('zh')) {
    redirect('/zh');
  }
  
  // Default to English
  redirect('/en');
}
