import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Progress } from '@/components/ui/progress';
import { 
  Globe, 
  TrendingUp, 
  Users, 
  DollarSign, 
  Shield,
  MapPin,
  Calendar,
  Target,
  CheckCircle,
  ArrowRight
} from 'lucide-react';
import { translations } from '@/lib/i18n/translations';
import type { Language } from '@/lib/i18n/translations';

export default async function ExpansionPage({
  params,
}: {
  params: Promise<{ lang: string }>;
}) {
  const { lang } = await params;
  const validLang = (lang === 'zh' ? 'zh' : 'en') as Language;

  const friendlyCountries = [
    {
      name: lang === 'zh' ? '新西兰' : 'New Zealand',
      nameLocal: 'New Zealand',
      flag: '🇳🇿',
      relationship: lang === 'zh' 
        ? '最亲密盟友，跨塔斯曼海伙伴关系' 
        : 'Closest ally, Trans-Tasman partnership',
      web3Stance: lang === 'zh' ? '非常友好' : 'Very Friendly',
      web3Desc: lang === 'zh' 
        ? 'FMA制定清晰监管框架，加密货币友好' 
        : 'FMA has clear regulatory framework, crypto-friendly',
      cryptoFriendly: 90,
      marketPotential: 75,
      priority: 1,
    },
    {
      name: lang === 'zh' ? '英国' : 'United Kingdom',
      nameLocal: 'United Kingdom',
      flag: '🇬🇧',
      relationship: lang === 'zh' 
        ? '传统盟友，Commonwealth核心成员' 
        : 'Traditional ally, Commonwealth core member',
      web3Stance: lang === 'zh' ? '积极支持' : 'Proactive Support',
      web3Desc: lang === 'zh' 
        ? 'FCA监管框架完善，伦敦 crypto hub' 
        : 'FCA regulatory framework complete, London crypto hub',
      cryptoFriendly: 85,
      marketPotential: 95,
      priority: 2,
    },
    {
      name: lang === 'zh' ? '美国' : 'United States',
      nameLocal: 'United States',
      flag: '🇺🇸',
      relationship: lang === 'zh' 
        ? '重要战略伙伴，AUKUS盟友' 
        : 'Important strategic partner, AUKUS ally',
      web3Stance: lang === 'zh' ? '逐步明确' : 'Gradually Clarifying',
      web3Desc: lang === 'zh' 
        ? 'SEC和CFTC监管博弈，大型机构入场' 
        : 'SEC vs CFTC regulatory battles, major institutions entering',
      cryptoFriendly: 70,
      marketPotential: 100,
      priority: 3,
    },
    {
      name: lang === 'zh' ? '日本' : 'Japan',
      nameLocal: '日本',
      flag: '🇯🇵',
      relationship: lang === 'zh' 
        ? '经济伙伴，亚太地区重要盟友' 
        : 'Economic partner, important Asia-Pacific ally',
      web3Stance: lang === 'zh' ? '规范发展' : 'Regulated Development',
      web3Desc: lang === 'zh' 
        ? '2017年合法化比特币，用户基础广泛' 
        : 'Bitcoin legalized in 2017, broad user base',
      cryptoFriendly: 80,
      marketPotential: 85,
      priority: 4,
    },
    {
      name: lang === 'zh' ? '新加坡' : 'Singapore',
      nameLocal: 'Singapore',
      flag: '🇸🇬',
      relationship: lang === 'zh' 
        ? '东南亚金融中心，紧密贸易伙伴' 
        : 'Southeast Asian financial center, close trade partner',
      web3Stance: lang === 'zh' ? '非常友好' : 'Very Friendly',
      web3Desc: lang === 'zh' 
        ? 'MAS积极支持，亚洲 crypto hub' 
        : 'MAS proactively supportive, Asia crypto hub',
      cryptoFriendly: 95,
      marketPotential: 90,
      priority: 5,
    },
    {
      name: lang === 'zh' ? '加拿大' : 'Canada',
      nameLocal: 'Canada',
      flag: '🇨🇦',
      relationship: lang === 'zh' 
        ? 'Commonwealth成员，印太战略伙伴' 
        : 'Commonwealth member, Indo-Pacific strategic partner',
      web3Stance: lang === 'zh' ? '开放友好' : 'Open and Friendly',
      web3Desc: lang === 'zh' 
        ? '多个大型交易所运营，监管清晰' 
        : 'Multiple major exchanges operating, clear regulation',
      cryptoFriendly: 85,
      marketPotential: 80,
      priority: 6,
    },
    {
      name: lang === 'zh' ? '德国' : 'Germany',
      nameLocal: 'Deutschland',
      flag: '🇩🇪',
      relationship: lang === 'zh' 
        ? '欧洲最大经济体，重要贸易伙伴' 
        : 'Largest European economy, important trade partner',
      web3Stance: lang === 'zh' ? '积极支持' : 'Proactive Support',
      web3Desc: lang === 'zh' 
        ? '允许银行托管加密货币，持有超1年免税' 
        : 'Banks allowed to custody crypto, holding >1yr tax-exempt',
      cryptoFriendly: 88,
      marketPotential: 88,
      priority: 7,
    },
    {
      name: lang === 'zh' ? '韩国' : 'South Korea',
      nameLocal: '대한민국',
      flag: '🇰🇷',
      relationship: lang === 'zh' 
        ? '亚太重要伙伴，经贸往来密切' 
        : 'Important Asia-Pacific partner, close trade ties',
      web3Stance: lang === 'zh' ? '规范但活跃' : 'Regulated but Active',
      web3Desc: lang === 'zh' 
        ? '年轻人crypto参与度高，交易市场活跃' 
        : 'High young population crypto participation, active trading',
      cryptoFriendly: 75,
      marketPotential: 82,
      priority: 8,
    },
    {
      name: lang === 'zh' ? '瑞士' : 'Switzerland',
      nameLocal: 'Schweiz',
      flag: '🇨🇭',
      relationship: lang === 'zh' 
        ? '金融合作伙伴，品质和创新象征' 
        : 'Financial cooperation partner, symbol of quality and innovation',
      web3Stance: lang === 'zh' ? '极度友好' : 'Extremely Friendly',
      web3Desc: lang === 'zh' 
        ? '"加密谷"所在地，税收优惠显著' 
        : '"Crypto Valley" location, significant tax benefits',
      cryptoFriendly: 98,
      marketPotential: 70,
      priority: 9,
    },
    {
      name: lang === 'zh' ? '荷兰' : 'Netherlands',
      nameLocal: 'Nederland',
      flag: '🇳🇱',
      relationship: lang === 'zh' 
        ? '欧洲重要伙伴，经贸合作紧密' 
        : 'Important European partner, close economic cooperation',
      web3Stance: lang === 'zh' ? '友好开放' : 'Friendly and Open',
      web3Desc: lang === 'zh' 
        ? ' Amsterdam区块链中心，创新氛围浓厚' 
        : 'Amsterdam blockchain hub, strong innovation atmosphere',
      cryptoFriendly: 85,
      marketPotential: 72,
      priority: 10,
    },
  ];

  const timeline = [
    {
      phase: lang === 'zh' ? '第一阶段' : 'Phase 1',
      days: '1-100',
      title: lang === 'zh' ? '本土巩固期' : 'Domestic Consolidation',
      description: lang === 'zh' 
        ? '巩固澳大利亚本土节点，建立标准运营流程' 
        : 'Consolidate Australian domestic nodes, establish standard operating procedures',
      tasks: [
        lang === 'zh' ? '完成悉尼、墨尔本、布里斯班三大节点建设' : 'Complete Sydney, Melbourne, Brisbane three major nodes',
        lang === 'zh' ? '建立标准化培训体系' : 'Establish standardized training system',
        lang === 'zh' ? '招募并培训首批核心成员' : 'Recruit and train first batch of core members',
        lang === 'zh' ? '完成盈利模式验证' : 'Complete revenue model validation',
        lang === 'zh' ? '建立财务管理规范' : 'Establish financial management standards',
      ],
      progress: 35,
    },
    {
      phase: lang === 'zh' ? '第二阶段' : 'Phase 2',
      days: '101-200',
      title: lang === 'zh' ? '区域扩展期' : 'Regional Expansion',
      description: lang === 'zh' 
        ? '进入亚太地区，建立区域中心' 
        : 'Enter Asia-Pacific region, establish regional hub',
      tasks: [
        lang === 'zh' ? '新西兰节点启动（Day 110）' : 'New Zealand node launch (Day 110)',
        lang === 'zh' ? '新加坡节点启动（Day 130）' : 'Singapore node launch (Day 130)',
        lang === 'zh' ? '日本节点启动（Day 150）' : 'Japan node launch (Day 150)',
        lang === 'zh' ? '韩国节点启动（Day 170）' : 'South Korea node launch (Day 170)',
        lang === 'zh' ? '建立亚太区域协调机制' : 'Establish Asia-Pacific regional coordination mechanism',
      ],
      progress: 15,
    },
    {
      phase: lang === 'zh' ? '第三阶段' : 'Phase 3',
      days: '201-300',
      title: lang === 'zh' ? '全球布局期' : 'Global Layout',
      description: lang === 'zh' 
        ? '进入欧美市场，完成全球10国布局' 
        : 'Enter European and American markets, complete global 10-country layout',
      tasks: [
        lang === 'zh' ? '英国节点启动（Day 210）' : 'UK node launch (Day 210)',
        lang === 'zh' ? '德国/瑞士节点启动（Day 230）' : 'Germany/Switzerland node launch (Day 230)',
        lang === 'zh' ? '美国节点启动（Day 250）' : 'US node launch (Day 250)',
        lang === 'zh' ? '加拿大/荷兰节点启动（Day 270）' : 'Canada/Netherlands node launch (Day 270)',
        lang === 'zh' ? '全球网络整合与优化' : 'Global network integration and optimization',
      ],
      progress: 5,
    },
  ];

  return (
    <div className="flex flex-col">
      {/* Hero */}
      <section className="py-20 bg-gradient-to-b from-primary/10 to-transparent">
        <div className="container">
          <div className="max-w-4xl mx-auto text-center">
            <Globe className="h-16 w-16 mx-auto mb-6 text-primary" />
            <h1 className="text-4xl md:text-5xl font-bold mb-6">
              {lang === 'zh' ? '全球扩展计划' : 'Global Expansion Plan'}
            </h1>
            <p className="text-xl text-muted-foreground mb-8">
              {lang === 'zh' 
                ? '从澳大利亚出发，连接全球最友好的10个国家' 
                : 'Starting from Australia, connecting the 10 most friendly countries worldwide'}
            </p>
            <div className="flex justify-center gap-4 flex-wrap">
              <Badge variant="outline" className="px-4 py-2 text-lg">
                <Calendar className="h-4 w-4 mr-2" />
                300 {lang === 'zh' ? '天计划' : 'Day Plan'}
              </Badge>
              <Badge variant="outline" className="px-4 py-2 text-lg">
                <Globe className="h-4 w-4 mr-2" />
                10 {lang === 'zh' ? '个国家' : ' Countries'}
              </Badge>
              <Badge variant="outline" className="px-4 py-2 text-lg">
                <Users className="h-4 w-4 mr-2" />
                100K+ {lang === 'zh' ? '成员目标' : 'Member Goal'}
              </Badge>
            </div>
          </div>
        </div>
      </section>

      {/* 300-Day Timeline */}
      <section className="py-20">
        <div className="container">
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-bold mb-4">
              {lang === 'zh' ? '300天执行计划' : '300-Day Execution Plan'}
            </h2>
          </div>
          <div className="max-w-4xl mx-auto">
            <div className="relative">
              {/* Timeline Line */}
              <div className="absolute left-8 md:left-1/2 top-0 bottom-0 w-0.5 bg-border transform md:-translate-x-1/2" />
              
              {/* Timeline Items */}
              <div className="space-y-12">
                {timeline.map((phase, index) => (
                  <div key={index} className={`relative flex items-start gap-8 ${index % 2 === 0 ? 'md:flex-row' : 'md:flex-row-reverse'}`}>
                    {/* Circle */}
                    <div className="absolute left-8 md:left-1/2 w-8 h-8 rounded-full bg-primary text-primary-foreground flex items-center justify-center transform -translate-x-1/2 z-10">
                      <span className="text-xs font-bold">{phase.days.split('-')[0]}</span>
                    </div>
                    
                    {/* Content Card */}
                    <div className={`flex-1 ml-16 md:ml-0 ${index % 2 === 0 ? 'md:pr-12' : 'md:pl-12'}`}>
                      <Card className="hover:shadow-lg transition-shadow">
                        <CardHeader>
                          <div className="flex items-center justify-between mb-2">
                            <Badge variant="outline">{phase.phase}</Badge>
                            <span className="text-sm text-muted-foreground">{phase.days} {lang === 'zh' ? '天' : 'Days'}</span>
                          </div>
                          <CardTitle className="text-2xl">{phase.title}</CardTitle>
                          <CardDescription className="text-base mt-2">{phase.description}</CardDescription>
                        </CardHeader>
                        <CardContent>
                          <div className="space-y-2 mb-4">
                            <div className="flex justify-between text-sm">
                              <span className="text-muted-foreground">{lang === 'zh' ? '完成进度' : 'Progress'}</span>
                              <span className="font-medium">{phase.progress}%</span>
                            </div>
                            <Progress value={phase.progress} className="h-2" />
                          </div>
                          <div className="space-y-2">
                            {phase.tasks.map((task, tIndex) => (
                              <div key={tIndex} className="flex items-start gap-2 text-sm">
                                <CheckCircle className="h-4 w-4 text-primary mt-0.5 flex-shrink-0" />
                                <span>{task}</span>
                              </div>
                            ))}
                          </div>
                        </CardContent>
                      </Card>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Country Cards */}
      <section className="py-20 bg-muted/50">
        <div className="container">
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-bold mb-4">
              {lang === 'zh' ? '澳大利亚最友好的10个国家' : 'Top 10 Australia-Friendly Countries'}
            </h2>
            <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
              {lang === 'zh' 
                ? '深入分析各国与澳大利亚的关系及WEB3态度' 
                : 'In-depth analysis of relationships with Australia and WEB3 stance'}
            </p>
          </div>
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6 max-w-7xl mx-auto">
            {friendlyCountries.map((country, index) => (
              <Card key={index} className="hover:shadow-lg transition-shadow">
                <CardHeader>
                  <div className="flex items-center justify-between mb-4">
                    <div className="flex items-center gap-3">
                      <span className="text-4xl">{country.flag}</span>
                      <div>
                        <CardTitle className="text-xl">{country.name}</CardTitle>
                        <p className="text-sm text-muted-foreground">{country.nameLocal}</p>
                      </div>
                    </div>
                    <Badge variant="outline" className="text-xs">
                      #{country.priority}
                    </Badge>
                  </div>
                  <CardDescription className="flex items-center gap-2">
                    <Users className="h-4 w-4" />
                    {country.relationship}
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="bg-muted/50 rounded-lg p-4">
                    <div className="flex items-center justify-between mb-2">
                      <span className="text-sm font-medium flex items-center gap-2">
                        <Shield className="h-4 w-4" />
                        {lang === 'zh' ? 'WEB3态度' : 'WEB3 Stance'}
                      </span>
                      <Badge className={country.cryptoFriendly >= 85 ? 'bg-green-500' : country.cryptoFriendly >= 75 ? 'bg-yellow-500' : 'bg-orange-500'}>
                        {country.web3Stance}
                      </Badge>
                    </div>
                    <p className="text-xs text-muted-foreground">{country.web3Desc}</p>
                  </div>
                  
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <div className="flex justify-between text-xs mb-1">
                        <span>{lang === 'zh' ? '加密友好度' : 'Crypto Friendly'}</span>
                        <span className="font-medium">{country.cryptoFriendly}%</span>
                      </div>
                      <Progress value={country.cryptoFriendly} className="h-1.5" />
                    </div>
                    <div>
                      <div className="flex justify-between text-xs mb-1">
                        <span>{lang === 'zh' ? '市场潜力' : 'Market Potential'}</span>
                        <span className="font-medium">{country.marketPotential}%</span>
                      </div>
                      <Progress value={country.marketPotential} className="h-1.5" />
                    </div>
                  </div>

                  <Button variant="outline" className="w-full" size="sm">
                    {lang === 'zh' ? '查看详情' : 'View Details'} <ArrowRight className="ml-2 h-4 w-4" />
                  </Button>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Success Metrics */}
      <section className="py-20">
        <div className="container">
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-bold mb-4">
              {lang === 'zh' ? '成功指标' : 'Success Metrics'}
            </h2>
          </div>
          <div className="grid md:grid-cols-4 gap-8 max-w-6xl mx-auto">
            <div className="text-center">
              <div className="h-20 w-20 rounded-full bg-primary/10 flex items-center justify-center mx-auto mb-4">
                <Target className="h-10 w-10 text-primary" />
              </div>
              <div className="text-4xl font-bold mb-2">10</div>
              <div className="text-muted-foreground">{lang === 'zh' ? '覆盖国家' : 'Countries Covered'}</div>
            </div>
            <div className="text-center">
              <div className="h-20 w-20 rounded-full bg-primary/10 flex items-center justify-center mx-auto mb-4">
                <Users className="h-10 w-10 text-primary" />
              </div>
              <div className="text-4xl font-bold mb-2">50K+</div>
              <div className="text-muted-foreground">{lang === 'zh' ? '活跃成员' : 'Active Members'}</div>
            </div>
            <div className="text-center">
              <div className="h-20 w-20 rounded-full bg-primary/10 flex items-center justify-center mx-auto mb-4">
                <MapPin className="h-10 w-10 text-primary" />
              </div>
              <div className="text-4xl font-bold mb-2">50+</div>
              <div className="text-muted-foreground">{lang === 'zh' ? '城市节点' : 'Urban Nodes'}</div>
            </div>
            <div className="text-center">
              <div className="h-20 w-20 rounded-full bg-primary/10 flex items-center justify-center mx-auto mb-4">
                <DollarSign className="h-10 w-10 text-primary" />
              </div>
              <div className="text-4xl font-bold mb-2">$10M</div>
              <div className="text-muted-foreground">{lang === 'zh' ? '管理资产' : 'Assets Under Management'}</div>
            </div>
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="py-20 bg-gradient-to-r from-primary to-teal-500 text-white">
        <div className="container text-center">
          <TrendingUp className="h-16 w-16 mx-auto mb-6 opacity-80" />
          <h2 className="text-3xl md:text-4xl font-bold mb-4">
            {lang === 'zh' ? '加入全球扩展计划' : 'Join the Global Expansion Plan'}
          </h2>
          <p className="text-xl mb-8 max-w-2xl mx-auto opacity-90">
            {lang === 'zh' 
              ? '成为EACO早期成员，参与全球扩展，共同创造历史' 
              : 'Become an early EACO member, participate in global expansion, create history together'}
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button size="lg" variant="secondary" className="text-lg">
              {lang === 'zh' ? '立即投资' : 'Invest Now'} <ArrowRight className="ml-2 h-5 w-5" />
            </Button>
            <Button size="lg" variant="outline" className="text-lg border-white text-white hover:bg-white hover:text-primary">
              {lang === 'zh' ? '了解更多' : 'Learn More'}
            </Button>
          </div>
        </div>
      </section>
    </div>
  );
}
