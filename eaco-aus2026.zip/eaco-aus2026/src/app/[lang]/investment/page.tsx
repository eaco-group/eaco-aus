import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Check, Sparkles, Crown, Building2, ArrowRight, DollarSign, Users, BookOpen, TrendingUp, Headphones } from 'lucide-react';
import { translations } from '@/lib/i18n/translations';
import type { Language } from '@/lib/i18n/translations';

export default async function InvestmentPage({
  params,
}: {
  params: Promise<{ lang: string }>;
}) {
  const { lang } = await params;
  const validLang = (lang === 'zh' ? 'zh' : 'en') as Language;

  const plans = [
    {
      name: lang === 'zh' ? '起步计划' : 'Starter Plan',
      price: '5,000',
      currency: 'AUD',
      period: lang === 'zh' ? '12个月' : '12 Months',
      icon: Sparkles,
      featured: false,
      description: lang === 'zh' 
        ? '适合初创者和WEB3新手，开启您的EACO之旅' 
        : 'Perfect for startups and WEB3 beginners, start your EACO journey',
      features: [
        lang === 'zh' ? '12个月会员资格' : '12-month membership',
        lang === 'zh' ? '基础培训课程（6门）' : 'Basic training courses (6)',
        lang === 'zh' ? '社区访问权限' : 'Community access',
        lang === 'zh' ? '月度行业报告' : 'Monthly industry reports',
        lang === 'zh' ? '参与线下活动' : 'Participate in offline events',
        lang === 'zh' ? '邮件支持' : 'Email support',
        lang === 'zh' ? '资源库访问' : 'Resource library access',
      ],
      notIncluded: [
        lang === 'zh' ? '1对1导师辅导' : '1-on-1 mentor coaching',
        lang === 'zh' ? '战略咨询' : 'Strategic consulting',
        lang === 'zh' ? '项目优先参与权' : 'Project priority access',
      ],
    },
    {
      name: lang === 'zh' ? '专业计划' : 'Professional Plan',
      price: '50,000',
      currency: 'AUD',
      period: lang === 'zh' ? '24个月' : '24 Months',
      icon: Crown,
      featured: true,
      description: lang === 'zh' 
        ? '最受欢迎的选择，适合认真发展的专业人士' 
        : 'Most popular choice for serious professionals',
      features: [
        lang === 'zh' ? '24个月会员资格' : '24-month membership',
        lang === 'zh' ? '全部高级课程（20+门）' : 'All advanced courses (20+)',
        lang === 'zh' ? '优先社区权限' : 'Priority community access',
        lang === 'zh' ? '周度行业报告' : 'Weekly industry reports',
        lang === 'zh' ? 'VIP活动邀请' : 'VIP event invitations',
        lang === 'zh' ? '1对1导师辅导（月2次）' : '1-on-1 mentor coaching (2/month)',
        lang === 'zh' ? '季度战略咨询' : 'Quarterly strategic consulting',
        lang === 'zh' ? '高潜力项目优先参与权' : 'High-potential project priority access',
        lang === 'zh' ? '行业专家 networking' : 'Industry expert networking',
        lang === 'zh' ? '优先海外节点考察' : 'Priority overseas node visits',
      ],
      notIncluded: [
        lang === 'zh' ? '区域独家经营权' : 'Regional exclusivity',
        lang === 'zh' ? '利润分成' : 'Profit sharing',
      ],
    },
    {
      name: lang === 'zh' ? '企业计划' : 'Enterprise Plan',
      price: lang === 'zh' ? '定制方案' : 'Custom',
      currency: '',
      period: lang === 'zh' ? '长期合作' : 'Long-term Partnership',
      icon: Building2,
      featured: false,
      description: lang === 'zh' 
        ? '为机构和企业设计的全方位合作伙伴方案' 
        : 'Comprehensive partnership designed for institutions and enterprises',
      features: [
        lang === 'zh' ? '无限期会员资格' : 'Unlimited membership',
        lang === 'zh' ? '定制化培训方案' : 'Customized training programs',
        lang === 'zh' ? '专属客户经理' : 'Dedicated account manager',
        lang === 'zh' ? '全天候优先支持' : '24/7 priority support',
        lang === 'zh' ? '战略规划咨询' : 'Strategic planning consultation',
        lang === 'zh' ? '区域独家经营权' : 'Regional exclusivity',
        lang === 'zh' ? '联合品牌机会' : 'Co-branding opportunities',
        lang === 'zh' ? '利润分成计划' : 'Profit sharing plan',
        lang === 'zh' ? '董事会席位' : 'Board seat',
        lang === 'zh' ? '技术团队支持' : 'Technical team support',
      ],
      notIncluded: [],
    },
  ];

  const revenueModels = [
    {
      icon: DollarSign,
      title: lang === 'zh' ? '会员费' : 'Membership Fees',
      description: lang === 'zh' 
        ? '稳定的订阅收入，支持组织运营' 
        : 'Stable subscription revenue supporting operations',
    },
    {
      icon: BookOpen,
      title: lang === 'zh' ? '培训项目' : 'Training Programs',
      description: lang === 'zh' 
        ? '高质量教育内容，创造持续收入' 
        : 'High-quality educational content creating recurring revenue',
    },
    {
      icon: Headphones,
      title: lang === 'zh' ? '咨询服务' : 'Consulting Services',
      description: lang === 'zh' 
        ? '为企业提供WEB3转型咨询' 
        : 'Providing WEB3 transformation consulting for enterprises',
    },
    {
      icon: Users,
      title: lang === 'zh' ? '合作项目' : 'Partnership Programs',
      description: lang === 'zh' 
        ? '与品牌和机构合作，共建生态' 
        : 'Partnering with brands and institutions to build ecosystem',
    },
    {
      icon: TrendingUp,
      title: lang === 'zh' ? '项目投资' : 'Project Investments',
      description: lang === 'zh' 
        ? '发掘并投资优质早期项目' 
        : 'Discovering and investing in quality early-stage projects',
    },
  ];

  return (
    <div className="flex flex-col">
      {/* Hero */}
      <section className="py-20 bg-gradient-to-b from-primary/10 to-transparent">
        <div className="container">
          <div className="max-w-4xl mx-auto text-center">
            <h1 className="text-4xl md:text-5xl font-bold mb-6">
              {lang === 'zh' ? '投资方案' : 'Investment Plans'}
            </h1>
            <p className="text-xl text-muted-foreground mb-8">
              {lang === 'zh' 
                ? '选择适合您的投资级别，开启您的EACO之旅' 
                : 'Choose your investment level and start your EACO journey'}
            </p>
          </div>
        </div>
      </section>

      {/* Investment Plans */}
      <section className="py-12">
        <div className="container">
          <div className="grid md:grid-cols-3 gap-8 max-w-6xl mx-auto">
            {plans.map((plan, index) => (
              <Card 
                key={index} 
                className={`relative ${plan.featured ? 'border-2 border-primary shadow-xl scale-105' : ''}`}
              >
                {plan.featured && (
                  <div className="absolute -top-4 left-1/2 -translate-x-1/2">
                    <Badge className="bg-primary text-primary-foreground px-4 py-1">
                      {lang === 'zh' ? '最受欢迎' : 'Most Popular'}
                    </Badge>
                  </div>
                )}
                <CardHeader className="text-center pb-4">
                  <div className={`h-16 w-16 rounded-full mx-auto mb-4 flex items-center justify-center ${
                    plan.featured ? 'bg-primary text-primary-foreground' : 'bg-muted'
                  }`}>
                    <plan.icon className="h-8 w-8" />
                  </div>
                  <CardTitle className="text-2xl">{plan.name}</CardTitle>
                  <CardDescription>{plan.description}</CardDescription>
                  <div className="pt-4">
                    {plan.price !== (lang === 'zh' ? '定制方案' : 'Custom') ? (
                      <div className="flex items-baseline justify-center gap-1">
                        <span className="text-4xl font-bold">{plan.price}</span>
                        <span className="text-lg text-muted-foreground">{plan.currency}</span>
                      </div>
                    ) : (
                      <span className="text-4xl font-bold">{plan.price}</span>
                    )}
                    <p className="text-sm text-muted-foreground mt-1">{plan.period}</p>
                  </div>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="space-y-2">
                    {plan.features.map((feature, fIndex) => (
                      <div key={fIndex} className="flex items-start gap-2">
                        <Check className="h-5 w-5 text-primary mt-0.5 flex-shrink-0" />
                        <span className="text-sm">{feature}</span>
                      </div>
                    ))}
                    {plan.notIncluded.map((feature, fIndex) => (
                      <div key={fIndex} className="flex items-start gap-2 opacity-40">
                        <span className="h-5 w-5 flex-shrink-0 flex items-center justify-center text-sm">×</span>
                        <span className="text-sm">{feature}</span>
                      </div>
                    ))}
                  </div>
                  <Button 
                    className={`w-full mt-6 ${plan.featured ? '' : 'variant-outline'}`} 
                    size="lg"
                  >
                    {lang === 'zh' ? '立即咨询' : 'Contact Now'} <ArrowRight className="ml-2 h-4 w-4" />
                  </Button>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Revenue Models */}
      <section className="py-20 bg-muted/50">
        <div className="container">
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-bold mb-4">
              {lang === 'zh' ? '盈利模式' : 'Revenue Models'}
            </h2>
            <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
              {lang === 'zh' 
                ? '多元化、可持续的收入来源，确保组织长期健康发展' 
                : 'Diversified and sustainable revenue sources ensuring long-term healthy development'}
            </p>
          </div>
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6 max-w-6xl mx-auto">
            {revenueModels.map((model, index) => (
              <Card key={index} className="hover:shadow-lg transition-shadow">
                <CardHeader>
                  <div className="h-12 w-12 rounded-lg bg-primary/10 flex items-center justify-center mb-4">
                    <model.icon className="h-6 w-6 text-primary" />
                  </div>
                  <CardTitle>{model.title}</CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-muted-foreground">{model.description}</p>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Why Invest */}
      <section className="py-20">
        <div className="container">
          <div className="grid md:grid-cols-2 gap-12 items-center max-w-6xl mx-auto">
            <div>
              <h2 className="text-3xl md:text-4xl font-bold mb-6">
                {lang === 'zh' ? '为什么投资EACO？' : 'Why Invest in EACO?'}
              </h2>
              <div className="space-y-6">
                <div className="flex gap-4">
                  <div className="h-10 w-10 rounded-full bg-primary/10 flex items-center justify-center flex-shrink-0">
                    <span className="font-bold text-primary">1</span>
                  </div>
                  <div>
                    <h3 className="font-semibold mb-2">
                      {lang === 'zh' ? '先发优势' : 'First-Mover Advantage'}
                    </h3>
                    <p className="text-muted-foreground">
                      {lang === 'zh' 
                        ? '成为澳大利亚及友好国家首批EACO成员，享受早期发展红利' 
                        : 'Become one of the first EACO members in Australia and friendly countries, enjoying early development dividends'}
                    </p>
                  </div>
                </div>
                <div className="flex gap-4">
                  <div className="h-10 w-10 rounded-full bg-primary/10 flex items-center justify-center flex-shrink-0">
                    <span className="font-bold text-primary">2</span>
                  </div>
                  <div>
                    <h3 className="font-semibold mb-2">
                      {lang === 'zh' ? '全球网络' : 'Global Network'}
                    </h3>
                    <p className="text-muted-foreground">
                      {lang === 'zh' 
                        ? '连接到全球创新者网络，获取无限商业机会' 
                        : 'Connect to a global network of innovators and gain unlimited business opportunities'}
                    </p>
                  </div>
                </div>
                <div className="flex gap-4">
                  <div className="h-10 w-10 rounded-full bg-primary/10 flex items-center justify-center flex-shrink-0">
                    <span className="font-bold text-primary">3</span>
                  </div>
                  <div>
                    <h3 className="font-semibold mb-2">
                      {lang === 'zh' ? '专业培训' : 'Professional Training'}
                    </h3>
                    <p className="text-muted-foreground">
                      {lang === 'zh' 
                        ? '获得最前沿的WEB3和区块链知识，保持竞争优势' 
                        : 'Gain cutting-edge WEB3 and blockchain knowledge and maintain competitive advantage'}
                    </p>
                  </div>
                </div>
                <div className="flex gap-4">
                  <div className="h-10 w-10 rounded-full bg-primary/10 flex items-center justify-center flex-shrink-0">
                    <span className="font-bold text-primary">4</span>
                  </div>
                  <div>
                    <h3 className="font-semibold mb-2">
                      {lang === 'zh' ? '社区价值' : 'Community Value'}
                    </h3>
                    <p className="text-muted-foreground">
                      {lang === 'zh' 
                        ? '随着社区增长和节点扩展，您的投资价值将持续提升' 
                        : 'As the community grows and nodes expand, your investment value will continue to increase'}
                    </p>
                  </div>
                </div>
              </div>
            </div>
            <div className="bg-gradient-to-br from-primary/10 to-teal-500/10 rounded-2xl p-8">
              <h3 className="text-2xl font-bold mb-6">
                {lang === 'zh' ? '联系我们开始投资' : 'Contact Us to Start Investing'}
              </h3>
              <div className="space-y-4">
                <div className="flex items-center gap-3">
                  <div className="h-10 w-10 rounded-lg bg-background flex items-center justify-center">
                    <Sparkles className="h-5 w-5 text-primary" />
                  </div>
                  <div>
                    <p className="font-medium">{lang === 'zh' ? '起步投资' : 'Start Investing'}</p>
                    <p className="text-sm text-muted-foreground">5,000 AUD</p>
                  </div>
                </div>
                <div className="flex items-center gap-3">
                  <div className="h-10 w-10 rounded-lg bg-background flex items-center justify-center">
                    <Crown className="h-5 w-5 text-primary" />
                  </div>
                  <div>
                    <p className="font-medium">{lang === 'zh' ? '专业投资' : 'Professional'}</p>
                    <p className="text-sm text-muted-foreground">50,000 AUD</p>
                  </div>
                </div>
                <div className="flex items-center gap-3">
                  <div className="h-10 w-10 rounded-lg bg-background flex items-center justify-center">
                    <Building2 className="h-5 w-5 text-primary" />
                  </div>
                  <div>
                    <p className="font-medium">{lang === 'zh' ? '企业合作' : 'Enterprise'}</p>
                    <p className="text-sm text-muted-foreground">{lang === 'zh' ? '定制方案' : 'Custom Plan'}</p>
                  </div>
                </div>
              </div>
              <Button className="w-full mt-6" size="lg">
                {lang === 'zh' ? '预约咨询' : 'Schedule Consultation'} <ArrowRight className="ml-2 h-4 w-4" />
              </Button>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}
