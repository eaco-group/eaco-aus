import type { Metadata } from 'next';
import { translations } from '@/lib/i18n/translations';
import { Header } from '@/components/layout/header';
import { Footer } from '@/components/layout/footer';
import type { Language } from '@/lib/i18n/translations';

export async function generateMetadata({
  params,
}: {
  params: Promise<{ lang: string }>;
}): Promise<Metadata> {
  const { lang } = await params;
  const isZh = lang === 'zh';

  return {
    title: {
      default: isZh ? '澳大利亚 EACO 社区' : 'Australia EACO Community',
      template: `%s | EACO`,
    },
    description: isZh
      ? 'EACO澳大利亚社区官方网站 - 连接创新者，共创美好未来'
      : 'Official website of EACO Australia Community - Connecting Innovators, Building a Better Future',
    keywords: isZh
      ? ['EACO', '澳大利亚', '创新社区', 'WEB3', '区块链', '志愿者']
      : ['EACO', 'Australia', 'Innovation Community', 'WEB3', 'Blockchain', 'Volunteer'],
  };
}

export default async function LangLayout({
  children,
  params,
}: {
  children: React.ReactNode;
  params: Promise<{ lang: string }>;
}) {
  const { lang } = await params;
  const validLang = (lang === 'zh' ? 'zh' : 'en') as Language;

  return (
    <div className="min-h-screen flex flex-col">
      <Header lang={validLang} dictionary={translations} />
      <main className="flex-1">{children}</main>
      <Footer lang={validLang} dictionary={translations} />
    </div>
  );
}
