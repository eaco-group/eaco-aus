'use client';

import { useState } from 'react';
import { Card, CardContent } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from '@/components/ui/accordion';
import { Badge } from '@/components/ui/badge';
import { Search, Shield, Globe, BookOpen, TrendingUp, Heart, Code, Users, Target, Rocket } from 'lucide-react';

interface FAQPageProps {
  lang: 'zh' | 'en';
  dictionary: Record<string, { zh: string; en: string }>;
}

const faqData = {
  zh: [
    // Ⅰ. 基础认知（1–10）
    {
      category: 'basic',
      question: 'EACO 是什么？',
      answer: 'EACO（Earth\'s Best Coin）是一种基于 Solana 的社区 MEME 资产，定位为"地球村文明 Meme"，由全球志愿者共同推动，不属于任何公司或个人。',
    },
    {
      category: 'basic',
      question: 'EACO 的合约地址是什么？',
      answer: 'Solana CA：DqfoyZH96RnvZusSp3Cdncjpyp3C74ZmJzGhjmHnDHRH',
    },
    {
      category: 'basic',
      question: 'EACO 是不是官方项目？',
      answer: 'EACO 没有"官方"，只有社区。所有频道、志愿者、内容都由全球网友自发贡献。',
    },
    {
      category: 'basic',
      question: 'EACO 是否进行过募资？',
      answer: '没有。EACO 无预售、无募资、无团队分配、无锁仓。',
    },
    {
      category: 'basic',
      question: 'EACO 的愿景是什么？',
      answer: '让全球村民通过 Meme、公益、跨文化协作，共同构建一个开放、透明、无国界的数字文明符号。',
    },
    {
      category: 'basic',
      question: 'EACO 的价值来自哪里？',
      answer: '来自社区共识、文化传播、流动性、使用场景与全球志愿者的持续贡献。',
    },
    {
      category: 'basic',
      question: 'EACO 是不是投资？',
      answer: '不是。EACO 是社区文化资产，不提供任何投资建议。',
    },
    {
      category: 'basic',
      question: 'EACO 的供应量是多少？',
      answer: '供应量固定，由 Solana 链上合约决定，不可更改。',
    },
    {
      category: 'basic',
      question: 'EACO 是否属于某个国家？',
      answer: '不属于任何国家，属于全球村民。',
    },
    {
      category: 'basic',
      question: 'EACO 是否有团队？',
      answer: '没有传统意义的团队，只有全球志愿者。',
    },

    // Ⅱ. 安全与防骗（11–20）
    {
      category: 'security',
      question: '如何验证频道是否真实？',
      answer: '通过交叉验证：Twitter、Linktree、Telegram 群组是否互相指向。',
    },
    {
      category: 'security',
      question: '如何判断管理员是否可信？',
      answer: '看是否愿意做"钱包所有权验证"（例如：发送 2000 e → 退回 1000 e）。',
    },
    {
      category: 'security',
      question: '如何判断是否诈骗？',
      answer: '诈骗特征：1) 不愿意验证钱包；2) 不愿意公开交易记录；3) 不愿意展示贡献成果；4) 承诺收益（100%诈骗）。',
    },
    {
      category: 'security',
      question: '如何验证钱包是否真实？',
      answer: '查看 Solscan 是否有交易历史、是否长期使用。',
    },
    {
      category: 'security',
      question: '如何验证是否真的在做事？',
      answer: '要求对方提供：内容、推广记录、数据、截图、成果。',
    },
    {
      category: 'security',
      question: '如果付费后没有效果怎么办？',
      answer: '社区常见做法：1) 退款；2) 部分退款；3) 延长服务。由双方自行协商。',
    },
    {
      category: 'security',
      question: '如何避免被骗？',
      answer: '1) 小额测试；2) 分阶段付款；3) 公开透明；4) 只与愿意验证身份的人合作。',
    },
    {
      category: 'security',
      question: 'EACO 是否会主动私聊？',
      answer: '不会。任何私聊索要资产的都是诈骗。',
    },
    {
      category: 'security',
      question: '是否可以举报诈骗？',
      answer: '可以在社区群组公开证据，由志愿者协助提醒其他用户。',
    },
    {
      category: 'security',
      question: 'EACO 是否保证价格？',
      answer: '不保证。任何保证价格的都是诈骗。',
    },

    // Ⅲ. 交易与流动性（21–30）
    {
      category: 'trading',
      question: '在哪里可以交易 EACO？',
      answer: 'Orca、Raydium、Meteora DLMM 等去中心化交易所。',
    },
    {
      category: 'trading',
      question: '如何增加 E-SOL 流动性？',
      answer: '通过 Raydium 添加流动性（用户自愿行为）。',
    },
    {
      category: 'trading',
      question: '如何增加 E-USDT 流动性？',
      answer: '通过 Meteora DLMM 添加流动性。',
    },
    {
      category: 'trading',
      question: '流动性是否安全？',
      answer: '流动性由用户自己掌控，EACO 不托管任何资产。',
    },
    {
      category: 'trading',
      question: '添加流动性是否有风险？',
      answer: '有，包括无常损失、价格波动等。请充分了解风险后谨慎操作。',
    },
    {
      category: 'trading',
      question: 'EACO 是否会上 CEX？',
      answer: '由社区推动，EACO 不主动申请。',
    },
    {
      category: 'trading',
      question: '如何查看 EACO 的链上数据？',
      answer: '使用 Solscan、Birdeye、Dexscreener 查看。',
    },
    {
      category: 'trading',
      question: '如何查看 EACO 的持币人数？',
      answer: '在 Solscan → Token → Holders 查看。',
    },
    {
      category: 'trading',
      question: '如何查看流动性池？',
      answer: '在 Raydium / Orca / Meteora 查看。',
    },
    {
      category: 'trading',
      question: '是否可以销毁代币？',
      answer: '任何人都可以自愿销毁自己的代币。',
    },

    // Ⅳ. 社区参与（31–40）
    {
      category: 'community',
      question: '如何成为志愿者？',
      answer: '直接在 Telegram 群组参与讨论、翻译、推广、创作即可。',
    },
    {
      category: 'community',
      question: '志愿者需要多久？',
      answer: '1–6 个月不等，完全自愿。',
    },
    {
      category: 'community',
      question: '志愿者是否有奖励？',
      answer: '不保证奖励，贡献越多，社区越认可。',
    },
    {
      category: 'community',
      question: '如何证明自己在做事？',
      answer: '提供内容、数据、截图、成果。',
    },
    {
      category: 'community',
      question: '如何加入全球语言群？',
      answer: '通过 Linktree 或官方频道列表加入。',
    },
    {
      category: 'community',
      question: '社区是否有层级？',
      answer: '没有，所有人平等。',
    },
    {
      category: 'community',
      question: '如何组织线下活动？',
      answer: '自发组织，社区可协助宣传。',
    },
    {
      category: 'community',
      question: '如何创建本地语言群？',
      answer: '自行创建并在主群申请挂载。',
    },
    {
      category: 'community',
      question: '如何成为管理员？',
      answer: '通过长期贡献、透明记录、社区投票。',
    },
    {
      category: 'community',
      question: '社区是否会封禁用户？',
      answer: '仅针对诈骗、骚扰、恶意行为。',
    },

    // Ⅴ. 文化与愿景（41–50）
    {
      category: 'culture',
      question: '为什么说 EACO 是"地球村第一 Meme"？',
      answer: '因为它以"地球文明"为主题，而非国家、动物或人物。',
    },
    {
      category: 'culture',
      question: 'EACO 的文化核心是什么？',
      answer: '地球、文明、公益、跨文化协作。',
    },
    {
      category: 'culture',
      question: '为什么叫 Earth\'s Best Coin？',
      answer: '象征"属于地球村民的共同资产"。',
    },
    {
      category: 'culture',
      question: '为什么是 $e？',
      answer: 'e = Earth、Energy、Everyone、Ecosystem。',
    },
    {
      category: 'culture',
      question: 'EACO 是否与环保相关？',
      answer: '社区鼓励环保行动，但不强制。',
    },
    {
      category: 'culture',
      question: 'EACO 是否与 AI 结合？',
      answer: '社区正在探索 AI 内容生产、AI 志愿者、AI 文明叙事。',
    },
    {
      category: 'culture',
      question: 'EACO 是否是宗教？',
      answer: '不是，是文化符号。',
    },
    {
      category: 'culture',
      question: 'EACO 是否属于某个组织？',
      answer: '不属于任何组织。',
    },
    {
      category: 'culture',
      question: 'EACO 是否会发展成 DAO？',
      answer: '社区正在讨论中。',
    },
    {
      category: 'culture',
      question: 'EACO 的长期目标是什么？',
      answer: '成为全球文明共识的数字符号。',
    },

    // Ⅵ. 技术与链上（51–60）
    {
      category: 'tech',
      question: 'EACO 基于什么链？',
      answer: 'Solana 链。',
    },
    {
      category: 'tech',
      question: '为什么选择 Solana？',
      answer: '速度快、费用低、生态活跃。',
    },
    {
      category: 'tech',
      question: 'EACO 是否可升级？',
      answer: '作为 SPL Token，不可修改。',
    },
    {
      category: 'tech',
      question: 'EACO 是否有智能合约？',
      answer: '是标准 SPL Token 合约。',
    },
    {
      category: 'tech',
      question: '是否可以跨链？',
      answer: '未来可能通过桥接实现。',
    },
    {
      category: 'tech',
      question: '是否可以在钱包中查看？',
      answer: 'Phantom、Solflare、OKX Wallet 等均可。',
    },
    {
      category: 'tech',
      question: '如何添加自定义代币？',
      answer: '输入合约地址即可。',
    },
    {
      category: 'tech',
      question: '是否有审计？',
      answer: 'SPL Token 本身无需审计。',
    },
    {
      category: 'tech',
      question: '是否可以创建子代币？',
      answer: '任何人都可以创建相关 Meme，但不代表 EACO。',
    },
    {
      category: 'tech',
      question: '是否可以做 NFT？',
      answer: '社区可自发创建。',
    },

    // Ⅶ. 公益与社会价值（61–70）
    {
      category: 'publicgood',
      question: 'EACO 是否做公益？',
      answer: '社区自发组织公益活动。',
    },
    {
      category: 'publicgood',
      question: '公益资金从哪里来？',
      answer: '志愿者自愿捐赠。',
    },
    {
      category: 'publicgood',
      question: '公益是否透明？',
      answer: '所有公益行为鼓励链上公开。',
    },
    {
      category: 'publicgood',
      question: '是否可以发起公益提案？',
      answer: '可以在群组提出。',
    },
    {
      category: 'publicgood',
      question: '公益是否强制？',
      answer: '完全自愿。',
    },
    {
      category: 'publicgood',
      question: '公益是否与价格相关？',
      answer: '无关。',
    },
    {
      category: 'publicgood',
      question: '公益是否需要许可？',
      answer: '不需要。',
    },
    {
      category: 'publicgood',
      question: '公益是否可以跨国？',
      answer: '可以。',
    },
    {
      category: 'publicgood',
      question: '公益是否可以与 NGO 合作？',
      answer: '可以。',
    },
    {
      category: 'publicgood',
      question: '公益是否会发证书？',
      answer: '社区可自发制作。',
    },

    // Ⅷ. 全球扩展（71–80）
    {
      category: 'global',
      question: 'EACO 有哪些语言社区？',
      answer: '中文、英文、阿拉伯语、西班牙语、法语、俄语、日韩东南亚等。',
    },
    {
      category: 'global',
      question: '如何加入全球推广？',
      answer: '在群组报名即可。',
    },
    {
      category: 'global',
      question: '如何验证海外管理员？',
      answer: '通过钱包验证 + 贡献记录。',
    },
    {
      category: 'global',
      question: '如何扩展到新国家？',
      answer: '创建语言群 + 本地内容。',
    },
    {
      category: 'global',
      question: '如何与 KOL 合作？',
      answer: '小额测试 + 透明合作。',
    },
    {
      category: 'global',
      question: '如何判断 KOL 是否有效？',
      answer: '看数据、互动、转化。',
    },
    {
      category: 'global',
      question: '是否可以做线下活动？',
      answer: '可以。',
    },
    {
      category: 'global',
      question: '是否可以做跨国合作？',
      answer: '可以。',
    },
    {
      category: 'global',
      question: '是否可以做品牌联名？',
      answer: '社区自发推动。',
    },
    {
      category: 'global',
      question: '是否可以做教育内容？',
      answer: '可以。',
    },

    // Ⅸ. 风险与合规（81–90）
    {
      category: 'risk',
      question: 'EACO 是否是证券？',
      answer: '不是。EACO 是社区 Meme 资产。',
    },
    {
      category: 'risk',
      question: '是否提供投资建议？',
      answer: '不提供。',
    },
    {
      category: 'risk',
      question: '是否承诺收益？',
      answer: '不承诺。',
    },
    {
      category: 'risk',
      question: '是否托管用户资产？',
      answer: '不托管。',
    },
    {
      category: 'risk',
      question: '是否需要实名？',
      answer: '不需要。',
    },
    {
      category: 'risk',
      question: '是否可以在中国大陆使用？',
      answer: '社区不建议在监管严格地区使用。',
    },
    {
      category: 'risk',
      question: '是否可以用于支付？',
      answer: '由商家自愿决定。',
    },
    {
      category: 'risk',
      question: '是否可以用于跨境？',
      answer: '由用户自行判断风险。',
    },
    {
      category: 'risk',
      question: '是否可以用于商业？',
      answer: '可以，但需自担风险。',
    },
    {
      category: 'risk',
      question: '是否会被监管？',
      answer: '任何数字资产都有可能被监管。',
    },

    // Ⅹ. 未来发展（91–100）
    {
      category: 'future',
      question: 'EACO 是否会做生态？',
      answer: '社区可自发构建。',
    },
    {
      category: 'future',
      question: '是否会做游戏？',
      answer: '可能由社区开发。',
    },
    {
      category: 'future',
      question: '是否会做 AI 工具？',
      answer: '社区正在探索。',
    },
    {
      category: 'future',
      question: '是否会做 DApp？',
      answer: '由开发者自发推动。',
    },
    {
      category: 'future',
      question: '是否会做跨链桥？',
      answer: '未来可能。',
    },
    {
      category: 'future',
      question: '是否会做全球 DAO？',
      answer: '社区正在讨论。',
    },
    {
      category: 'future',
      question: '是否会做品牌？',
      answer: '可能由社区推动。',
    },
    {
      category: 'future',
      question: '是否会做周边？',
      answer: '可以。',
    },
    {
      category: 'future',
      question: '是否会做全球大会？',
      answer: '社区可自发组织。',
    },
    {
      category: 'future',
      question: 'EACO 的最终目标是什么？',
      answer: '成为"地球文明的数字符号"，而不是一枚普通 Meme 币。',
    },
  ],

  en: [
    // Ⅰ. Basic Knowledge (1-10)
    {
      category: 'basic',
      question: 'What is EACO?',
      answer: 'EACO (Earth\'s Best Coin) is a community MEME asset based on Solana, positioned as the "Earth Village Civilization Meme", driven by global volunteers, and does not belong to any company or individual.',
    },
    {
      category: 'basic',
      question: 'What is the contract address of EACO?',
      answer: 'Solana CA: DqfoyZH96RnvZusSp3Cdncjpyp3C74ZmJzGhjmHnDHRH',
    },
    {
      category: 'basic',
      question: 'Is EACO an official project?',
      answer: 'EACO has no "official", only community. All channels, volunteers, and content are spontaneously contributed by global netizens.',
    },
    {
      category: 'basic',
      question: 'Has EACO conducted any fundraising?',
      answer: 'No. EACO has no presale, no fundraising, no team allocation, no lock-up.',
    },
    {
      category: 'basic',
      question: 'What is EACO\'s vision?',
      answer: 'Let global villagers build an open, transparent, borderless digital civilization symbol together through Meme, public welfare, and cross-cultural collaboration.',
    },
    {
      category: 'basic',
      question: 'Where does EACO\'s value come from?',
      answer: 'From community consensus, cultural spread, liquidity, use cases, and continuous contributions from global volunteers.',
    },
    {
      category: 'basic',
      question: 'Is EACO an investment?',
      answer: 'No. EACO is a community cultural asset and does not provide any investment advice.',
    },
    {
      category: 'basic',
      question: 'What is EACO\'s supply?',
      answer: 'Supply is fixed, determined by the Solana chain contract, cannot be changed.',
    },
    {
      category: 'basic',
      question: 'Does EACO belong to any country?',
      answer: 'Does not belong to any country, belongs to global villagers.',
    },
    {
      category: 'basic',
      question: 'Does EACO have a team?',
      answer: 'No traditional team, only global volunteers.',
    },

    // Ⅱ. Security & Anti-Scam (11-20)
    {
      category: 'security',
      question: 'How to verify if a channel is authentic?',
      answer: 'Cross-verify: check if Twitter, Linktree, Telegram groups point to each other.',
    },
    {
      category: 'security',
      question: 'How to judge if an admin is trustworthy?',
      answer: 'See if they are willing to do "wallet ownership verification" (e.g., send 2000 e → return 1000 e).',
    },
    {
      category: 'security',
      question: 'How to identify scams?',
      answer: 'Scam indicators: 1) Unwilling to verify wallet; 2) Unwilling to share transaction records; 3) Unwilling to show contributions; 4) Promising returns (100% scam).',
    },
    {
      category: 'security',
      question: 'How to verify if a wallet is real?',
      answer: 'Check Solscan for transaction history and long-term usage.',
    },
    {
      category: 'security',
      question: 'How to verify if someone is actually working?',
      answer: 'Ask for: content, promotion records, data, screenshots, results.',
    },
    {
      category: 'security',
      question: 'What to do if payment has no effect?',
      answer: 'Common practices: 1) Refund; 2) Partial refund; 3) Extended service. Negotiated between parties.',
    },
    {
      category: 'security',
      question: 'How to avoid being scammed?',
      answer: '1) Small test amounts; 2) Phased payments; 3) Transparency; 4) Only work with people willing to verify identity.',
    },
    {
      category: 'security',
      question: 'Will EACO initiate private chats?',
      answer: 'No. Any private chat asking for assets is a scam.',
    },
    {
      category: 'security',
      question: 'Can I report scams?',
      answer: 'You can post evidence in community groups for volunteers to help warn other users.',
    },
    {
      category: 'security',
      question: 'Does EACO guarantee price?',
      answer: 'No. Any price guarantee is a scam.',
    },

    // Ⅲ. Trading & Liquidity (21-30)
    {
      category: 'trading',
      question: 'Where can I trade EACO?',
      answer: 'Orca, Raydium, Meteora DLMM and other decentralized exchanges.',
    },
    {
      category: 'trading',
      question: 'How to add E-SOL liquidity?',
      answer: 'Add liquidity through Raydium (voluntary user behavior).',
    },
    {
      category: 'trading',
      question: 'How to add E-USDT liquidity?',
      answer: 'Add liquidity through Meteora DLMM.',
    },
    {
      category: 'trading',
      question: 'Is liquidity safe?',
      answer: 'Liquidity is controlled by users themselves, EACO does not custody any assets.',
    },
    {
      category: 'trading',
      question: 'Are there risks in adding liquidity?',
      answer: 'Yes, including impermanent loss, price volatility, etc. Operate carefully after fully understanding the risks.',
    },
    {
      category: 'trading',
      question: 'Will EACO list on CEX?',
      answer: 'Driven by community, EACO does not actively apply.',
    },
    {
      category: 'trading',
      question: 'How to view EACO\'s on-chain data?',
      answer: 'Use Solscan, Birdeye, Dexscreener.',
    },
    {
      category: 'trading',
      question: 'How to view EACO\'s holder count?',
      answer: 'View in Solscan → Token → Holders.',
    },
    {
      category: 'trading',
      question: 'How to view liquidity pools?',
      answer: 'View in Raydium / Orca / Meteora.',
    },
    {
      category: 'trading',
      question: 'Can tokens be burned?',
      answer: 'Anyone can voluntarily burn their own tokens.',
    },

    // Ⅳ. Community Participation (31-40)
    {
      category: 'community',
      question: 'How to become a volunteer?',
      answer: 'Just participate in discussions, translation, promotion, and creation in the Telegram group.',
    },
    {
      category: 'community',
      question: 'How long does volunteering take?',
      answer: '1-6 months or more, completely voluntary.',
    },
    {
      category: 'community',
      question: 'Are there rewards for volunteers?',
      answer: 'No guaranteed rewards, the more you contribute, the more the community recognizes you.',
    },
    {
      category: 'community',
      question: 'How to prove you are working?',
      answer: 'Provide content, data, screenshots, results.',
    },
    {
      category: 'community',
      question: 'How to join global language groups?',
      answer: 'Join through Linktree or official channel list.',
    },
    {
      category: 'community',
      question: 'Is there hierarchy in the community?',
      answer: 'No, everyone is equal.',
    },
    {
      category: 'community',
      question: 'How to organize offline events?',
      answer: 'Self-organize, community can assist with promotion.',
    },
    {
      category: 'community',
      question: 'How to create a local language group?',
      answer: 'Create yourself and apply for listing in the main group.',
    },
    {
      category: 'community',
      question: 'How to become an admin?',
      answer: 'Through long-term contributions, transparent records, community voting.',
    },
    {
      category: 'community',
      question: 'Will the community ban users?',
      answer: 'Only for scams, harassment, malicious behavior.',
    },

    // Ⅴ. Culture & Vision (41-50)
    {
      category: 'culture',
      question: 'Why is EACO the "First Earth Village Meme"?',
      answer: 'Because it focuses on "Earth Civilization" rather than countries, animals, or people.',
    },
    {
      category: 'culture',
      question: 'What is EACO\'s cultural core?',
      answer: 'Earth, Civilization, Public Welfare, Cross-cultural Collaboration.',
    },
    {
      category: 'culture',
      question: 'Why is it called Earth\'s Best Coin?',
      answer: 'Symbolizes "common asset belonging to Earth villagers".',
    },
    {
      category: 'culture',
      question: 'Why $e?',
      answer: 'e = Earth, Energy, Everyone, Ecosystem.',
    },
    {
      category: 'culture',
      question: 'Is EACO related to environmental protection?',
      answer: 'Community encourages environmental actions but does not enforce.',
    },
    {
      category: 'culture',
      question: 'Does EACO combine with AI?',
      answer: 'Community is exploring AI content production, AI volunteers, AI civilization narratives.',
    },
    {
      category: 'culture',
      question: 'Is EACO a religion?',
      answer: 'No, it is a cultural symbol.',
    },
    {
      category: 'culture',
      question: 'Does EACO belong to any organization?',
      answer: 'Does not belong to any organization.',
    },
    {
      category: 'culture',
      question: 'Will EACO develop into a DAO?',
      answer: 'Under community discussion.',
    },
    {
      category: 'culture',
      question: 'What is EACO\'s long-term goal?',
      answer: 'To become a digital symbol of global civilization consensus.',
    },

    // Ⅵ. Technology & On-Chain (51-60)
    {
      category: 'tech',
      question: 'What chain is EACO based on?',
      answer: 'Solana chain.',
    },
    {
      category: 'tech',
      question: 'Why choose Solana?',
      answer: 'Fast speed, low fees, active ecosystem.',
    },
    {
      category: 'tech',
      question: 'Can EACO be upgraded?',
      answer: 'As an SPL Token, cannot be modified.',
    },
    {
      category: 'tech',
      question: 'Does EACO have smart contracts?',
      answer: 'Standard SPL Token contract.',
    },
    {
      category: 'tech',
      question: 'Can it be cross-chain?',
      answer: 'May be achieved through bridging in the future.',
    },
    {
      category: 'tech',
      question: 'Can it be viewed in wallets?',
      answer: 'Phantom, Solflare, OKX Wallet, etc.',
    },
    {
      category: 'tech',
      question: 'How to add custom tokens?',
      answer: 'Enter the contract address.',
    },
    {
      category: 'tech',
      question: 'Is there an audit?',
      answer: 'SPL Token itself does not require audit.',
    },
    {
      category: 'tech',
      question: 'Can sub-tokens be created?',
      answer: 'Anyone can create related Meme, but does not represent EACO.',
    },
    {
      category: 'tech',
      question: 'Can NFTs be made?',
      answer: 'Community can create spontaneously.',
    },

    // Ⅶ. Public Welfare & Social Value (61-70)
    {
      category: 'publicgood',
      question: 'Does EACO do charity?',
      answer: 'Community organizes charity activities spontaneously.',
    },
    {
      category: 'publicgood',
      question: 'Where does charity funding come from?',
      answer: 'Voluntary donations from volunteers.',
    },
    {
      category: 'publicgood',
      question: 'Is charity transparent?',
      answer: 'All charity activities encouraged to be publicly disclosed on-chain.',
    },
    {
      category: 'publicgood',
      question: 'Can charity proposals be submitted?',
      answer: 'Can be proposed in group chats.',
    },
    {
      category: 'publicgood',
      question: 'Is charity mandatory?',
      answer: 'Completely voluntary.',
    },
    {
      category: 'publicgood',
      question: 'Is charity related to price?',
      answer: 'Unrelated.',
    },
    {
      category: 'publicgood',
      question: 'Is permission needed for charity?',
      answer: 'No permission needed.',
    },
    {
      category: 'publicgood',
      question: 'Can charity be cross-border?',
      answer: 'Yes.',
    },
    {
      category: 'publicgood',
      question: 'Can charity collaborate with NGOs?',
      answer: 'Yes.',
    },
    {
      category: 'publicgood',
      question: 'Will charity issue certificates?',
      answer: 'Community can create spontaneously.',
    },

    // Ⅷ. Global Expansion (71-80)
    {
      category: 'global',
      question: 'What language communities does EACO have?',
      answer: 'Chinese, English, Arabic, Spanish, French, Russian, Japanese, Korean, Southeast Asian, etc.',
    },
    {
      category: 'global',
      question: 'How to join global promotion?',
      answer: 'Sign up in the group.',
    },
    {
      category: 'global',
      question: 'How to verify overseas admins?',
      answer: 'Through wallet verification + contribution records.',
    },
    {
      category: 'global',
      question: 'How to expand to new countries?',
      answer: 'Create language groups + local content.',
    },
    {
      category: 'global',
      question: 'How to collaborate with KOLs?',
      answer: 'Small test + transparent collaboration.',
    },
    {
      category: 'global',
      question: 'How to judge KOL effectiveness?',
      answer: 'Check data, engagement, conversion.',
    },
    {
      category: 'global',
      question: 'Can offline events be held?',
      answer: 'Yes.',
    },
    {
      category: 'global',
      question: 'Can cross-border collaboration be done?',
      answer: 'Yes.',
    },
    {
      category: 'global',
      question: 'Can brand collaborations be done?',
      answer: 'Driven by community spontaneously.',
    },
    {
      category: 'global',
      question: 'Can educational content be made?',
      answer: 'Yes.',
    },

    // Ⅸ. Risk & Compliance (81-90)
    {
      category: 'risk',
      question: 'Is EACO a security?',
      answer: 'No. EACO is a community Meme asset.',
    },
    {
      category: 'risk',
      question: 'Does it provide investment advice?',
      answer: 'No.',
    },
    {
      category: 'risk',
      question: 'Does it promise returns?',
      answer: 'No promises.',
    },
    {
      category: 'risk',
      question: 'Does it custody user assets?',
      answer: 'No custody.',
    },
    {
      category: 'risk',
      question: 'Is real name required?',
      answer: 'No.',
    },
    {
      category: 'risk',
      question: 'Can it be used in mainland China?',
      answer: 'Community does not recommend using in strictly regulated areas.',
    },
    {
      category: 'risk',
      question: 'Can it be used for payment?',
      answer: 'Determined by merchants voluntarily.',
    },
    {
      category: 'risk',
      question: 'Can it be used for cross-border?',
      answer: 'Users assess risks themselves.',
    },
    {
      category: 'risk',
      question: 'Can it be used for business?',
      answer: 'Yes, but at your own risk.',
    },
    {
      category: 'risk',
      question: 'Can it be regulated?',
      answer: 'Any digital asset may be subject to regulation.',
    },

    // Ⅹ. Future Development (91-100)
    {
      category: 'future',
      question: 'Will EACO build an ecosystem?',
      answer: 'Community can build spontaneously.',
    },
    {
      category: 'future',
      question: 'Will games be made?',
      answer: 'May be developed by community.',
    },
    {
      category: 'future',
      question: 'Will AI tools be made?',
      answer: 'Community is exploring.',
    },
    {
      category: 'future',
      question: 'Will DApps be made?',
      answer: 'Driven by developers spontaneously.',
    },
    {
      category: 'future',
      question: 'Will cross-chain bridges be made?',
      answer: 'Possible in the future.',
    },
    {
      category: 'future',
      question: 'Will a global DAO be made?',
      answer: 'Under community discussion.',
    },
    {
      category: 'future',
      question: 'Will branding be done?',
      answer: 'May be driven by community.',
    },
    {
      category: 'future',
      question: 'Will merchandise be made?',
      answer: 'Yes.',
    },
    {
      category: 'future',
      question: 'Will global conferences be held?',
      answer: 'Community can organize spontaneously.',
    },
    {
      category: 'future',
      question: 'What is EACO\'s ultimate goal?',
      answer: 'To become "the digital symbol of Earth civilization", not an ordinary Meme coin.',
    },
  ],
};

const categories = {
  zh: [
    { value: 'basic', label: '基础认知', icon: BookOpen, color: 'bg-blue-500' },
    { value: 'security', label: '安全防骗', icon: Shield, color: 'bg-red-500' },
    { value: 'trading', label: '交易流动', icon: TrendingUp, color: 'bg-green-500' },
    { value: 'community', label: '社区参与', icon: Users, color: 'bg-purple-500' },
    { value: 'culture', label: '文化愿景', icon: Globe, color: 'bg-cyan-500' },
    { value: 'tech', label: '技术链上', icon: Code, color: 'bg-orange-500' },
    { value: 'publicgood', label: '公益价值', icon: Heart, color: 'bg-pink-500' },
    { value: 'global', label: '全球扩展', icon: Rocket, color: 'bg-indigo-500' },
    { value: 'risk', label: '风险合规', icon: Shield, color: 'bg-yellow-500' },
    { value: 'future', label: '未来发展', icon: Target, color: 'bg-teal-500' },
  ],
  en: [
    { value: 'basic', label: 'Basic Knowledge', icon: BookOpen, color: 'bg-blue-500' },
    { value: 'security', label: 'Security & Scam', icon: Shield, color: 'bg-red-500' },
    { value: 'trading', label: 'Trading & Liquidity', icon: TrendingUp, color: 'bg-green-500' },
    { value: 'community', label: 'Community', icon: Users, color: 'bg-purple-500' },
    { value: 'culture', label: 'Culture & Vision', icon: Globe, color: 'bg-cyan-500' },
    { value: 'tech', label: 'Tech & On-Chain', icon: Code, color: 'bg-orange-500' },
    { value: 'publicgood', label: 'Public Welfare', icon: Heart, color: 'bg-pink-500' },
    { value: 'global', label: 'Global Expansion', icon: Rocket, color: 'bg-indigo-500' },
    { value: 'risk', label: 'Risk & Compliance', icon: Shield, color: 'bg-yellow-500' },
    { value: 'future', label: 'Future Development', icon: Target, color: 'bg-teal-500' },
  ],
};

export default function FAQPage({ lang, dictionary }: FAQPageProps) {
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('all');

  // 安全处理：确保 lang 参数有效
  const safeLang = (lang === 'zh' || lang === 'en') ? lang : 'zh';
  const faqs = faqData[safeLang] || [];
  const categoryList = categories[safeLang] || [];

  const filteredFAQs = (faqs || []).filter((faq: { category: string; question: string; answer: string }) => {
    const matchesCategory = selectedCategory === 'all' || faq.category === selectedCategory;
    const matchesSearch = 
      faq.question.toLowerCase().includes(searchQuery.toLowerCase()) ||
      faq.answer.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesCategory && matchesSearch;
  });

  return (
    <div className="flex flex-col">
      {/* Hero */}
      <section className="py-20 bg-gradient-to-b from-primary/10 to-transparent">
        <div className="container">
          <div className="max-w-4xl mx-auto text-center">
            <h1 className="text-4xl md:text-5xl font-bold mb-6">
              {lang === 'zh' 
                ? 'EACO 100问与标准解答' 
                : 'EACO 100 Questions & Answers'}
            </h1>
            <p className="text-xl text-muted-foreground mb-4">
              {lang === 'zh' 
                ? '全球化、合规、安全、不承诺收益、强调社区自组织' 
                : 'Global, Compliant, Safe, No Return Promises, Community Self-Organization'}
            </p>
            <div className="flex flex-wrap justify-center gap-3 mb-6">
              <Badge variant="outline" className="px-4 py-2">
                📚 10 {lang === 'zh' ? '大类' : 'Categories'}
              </Badge>
              <Badge variant="outline" className="px-4 py-2">
                ❓ 100 {lang === 'zh' ? '个问题' : 'Questions'}
              </Badge>
              <Badge variant="outline" className="px-4 py-2">
                🌍 2026 {lang === 'zh' ? '全球版' : 'Global Version'}
              </Badge>
            </div>
            <div className="relative max-w-2xl mx-auto">
              <Search className="absolute left-4 top-1/2 -translate-y-1/2 h-5 w-5 text-muted-foreground" />
              <Input
                type="text"
                placeholder={lang === 'zh' ? '搜索问题...' : 'Search questions...'}
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-12 h-12 text-lg"
              />
            </div>
          </div>
        </div>
      </section>

      {/* Category Cards */}
      <section className="py-8 bg-muted/30">
        <div className="container">
          <div className="grid grid-cols-2 md:grid-cols-5 gap-3 max-w-5xl mx-auto">
            {categoryList.map((cat) => {
              const count = faqs.filter(f => f.category === cat.value).length;
              const Icon = cat.icon;
              return (
                <Card 
                  key={cat.value} 
                  className={`cursor-pointer transition-all hover:scale-105 ${
                    selectedCategory === cat.value ? 'ring-2 ring-primary' : ''
                  }`}
                  onClick={() => setSelectedCategory(selectedCategory === cat.value ? 'all' : cat.value)}
                >
                  <CardContent className="p-4 text-center">
                    <div className={`h-10 w-10 rounded-full ${cat.color} flex items-center justify-center mx-auto mb-2`}>
                      <Icon className="h-5 w-5 text-white" />
                    </div>
                    <div className="font-bold text-lg">{count}</div>
                    <div className="text-xs text-muted-foreground">{cat.label}</div>
                  </CardContent>
                </Card>
              );
            })}
          </div>
        </div>
      </section>

      {/* FAQ List */}
      <section className="py-12">
        <div className="container">
          <div className="max-w-4xl mx-auto">
            {/* Stats */}
            <div className="flex justify-between items-center mb-6">
              <p className="text-sm text-muted-foreground">
                {lang === 'zh' 
                  ? `显示 ${filteredFAQs.length} 个问题（共 ${faqs.length} 个）` 
                  : `Showing ${filteredFAQs.length} questions (total ${faqs.length})`}
              </p>
              {selectedCategory !== 'all' && (
                <button 
                  onClick={() => setSelectedCategory('all')}
                  className="text-sm text-primary hover:underline"
                >
                  {lang === 'zh' ? '清除筛选' : 'Clear filter'}
                </button>
              )}
            </div>

            {/* Accordion */}
            <Accordion type="single" collapsible className="w-full">
              {filteredFAQs.map((faq, index) => {
                const catInfo = categoryList.find(c => c.value === faq.category);
                return (
                  <AccordionItem key={index} value={`item-${index}`}>
                    <AccordionTrigger className="text-left">
                      <div className="flex items-center gap-3 flex-1 pr-4">
                        <Badge className={`${catInfo?.color || 'bg-gray-500'} text-white shrink-0`}>
                          {index + 1}
                        </Badge>
                        <span className="text-left flex-1">{faq.question}</span>
                      </div>
                    </AccordionTrigger>
                    <AccordionContent>
                      <div className="pl-14 pb-4">
                        <p className="text-muted-foreground leading-relaxed whitespace-pre-wrap">
                          {faq.answer}
                        </p>
                        <div className="mt-3 flex items-center gap-2">
                          <Badge variant="outline" className="text-xs">
                            {catInfo?.label}
                          </Badge>
                        </div>
                      </div>
                    </AccordionContent>
                  </AccordionItem>
                );
              })}
            </Accordion>

            {filteredFAQs.length === 0 && (
              <Card className="p-12 text-center">
                <Search className="h-12 w-12 mx-auto mb-4 text-muted-foreground" />
                <p className="text-muted-foreground">
                  {lang === 'zh' 
                    ? '没有找到匹配的问题，请尝试其他关键词' 
                    : 'No matching questions found, please try different keywords'}
                </p>
              </Card>
            )}
          </div>
        </div>
      </section>

      {/* Disclaimer */}
      <section className="py-8 bg-amber-50 border-t border-amber-200">
        <div className="container">
          <div className="max-w-4xl mx-auto">
            <div className="flex items-start gap-3">
              <Shield className="h-6 w-6 text-amber-600 shrink-0 mt-1" />
              <div>
                <h4 className="font-semibold text-amber-900 mb-2">
                  {lang === 'zh' ? '重要声明' : 'Important Disclaimer'}
                </h4>
                <p className="text-sm text-amber-800">
                  {lang === 'zh' 
                    ? 'EACO 是社区文化资产，不提供任何投资建议，不承诺任何收益。数字资产投资有风险，请谨慎决策。任何保证收益的都是诈骗。' 
                    : 'EACO is a community cultural asset and does not provide any investment advice or promise any returns. Digital asset investment involves risks, please make decisions carefully. Anyone promising returns is a scam.'}
                </p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Contact CTA */}
      <section className="py-12 bg-muted/50">
        <div className="container">
          <div className="max-w-2xl mx-auto text-center">
            <h3 className="text-2xl font-bold mb-4">
              {lang === 'zh' ? '还有其他问题？' : 'Still have questions?'}
            </h3>
            <p className="text-muted-foreground mb-6">
              {lang === 'zh' 
                ? '加入社区，与全球村民交流' 
                : 'Join the community and connect with global villagers'}
            </p>
            <div className="flex flex-wrap justify-center gap-3">
              <Badge variant="outline" className="px-6 py-3 text-base cursor-pointer hover:bg-accent">
                📱 Telegram
              </Badge>
              <Badge variant="outline" className="px-6 py-3 text-base cursor-pointer hover:bg-accent">
                🐦 Twitter/X
              </Badge>
              <Badge variant="outline" className="px-6 py-3 text-base cursor-pointer hover:bg-accent">
                🔗 Linktree
              </Badge>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}
