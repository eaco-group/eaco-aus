import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { 
  Globe,
  Shield,
  TrendingUp,
  AlertTriangle,
  CheckCircle,
  DollarSign,
  Users,
  Building2,
  BarChart3,
  Lightbulb
} from 'lucide-react';
import { translations } from '@/lib/i18n/translations';
import type { Language } from '@/lib/i18n/translations';

export default async function Web3Page({
  params,
}: {
  params: Promise<{ lang: string }>;
}) {
  const { lang } = await params;
  const validLang = (lang === 'zh' ? 'zh' : 'en') as Language;

  const australiaAnalysis = {
    overall: lang === 'zh' ? '积极开放' : 'Positive and Open',
    overallScore: 82,
    summary: lang === 'zh' 
      ? '澳大利亚对WEB3和区块链技术持开放态度，政府正在完善监管框架，同时支持创新发展。'
      : 'Australia has an open attitude toward WEB3 and blockchain technology, with the government improving regulatory frameworks while supporting innovation.',
  };

  const regulatoryAspects = [
    {
      icon: Building2,
      title: lang === 'zh' ? '监管机构' : 'Regulatory Bodies',
      status: lang === 'zh' ? '完善中' : 'Improving',
      description: lang === 'zh' 
        ? 'ASIC负责加密资产监管，2021年发布数字资产监管框架指导' 
        : 'ASIC is responsible for crypto asset regulation, issued digital asset regulatory framework guidance in 2021',
      score: 75,
    },
    {
      icon: Shield,
      title: lang === 'zh' ? 'AML/KYC要求' : 'AML/KYC Requirements',
      status: lang === 'zh' ? '严格执行' : 'Strictly Enforced',
      description: lang === 'zh' 
        ? '加密货币交易所必须遵守反洗钱和了解客户规定' 
        : 'Cryptocurrency exchanges must comply with AML and KYC regulations',
      score: 85,
    },
    {
      icon: DollarSign,
      title: lang === 'zh' ? '税务处理' : 'Tax Treatment',
      status: lang === 'zh' ? '明确' : 'Clear',
      description: lang === 'zh' 
        ? 'ATO发布数字货币税务指南，交易不征GST，资本利得税适用' 
        : 'ATO issues digital currency tax guide, transactions not subject to GST, CGT applies',
      score: 80,
    },
    {
      icon: Users,
      title: lang === 'zh' ? '消费者保护' : 'Consumer Protection',
      status: lang === 'zh' ? '逐步完善' : 'Gradually Improving',
      description: lang === 'zh' 
        ? '政府加强投资者保护措施，但仍在发展中' 
        : 'Government strengthening investor protection measures, still in development',
      score: 70,
    },
  ];

  const opportunities = [
    {
      icon: TrendingUp,
      title: lang === 'zh' ? 'DeFi 发展' : 'DeFi Development',
      description: lang === 'zh' 
        ? '去中心化金融在澳大利亚快速增长，本地Dex和借贷平台活跃' 
        : 'DeFi is growing rapidly in Australia with active local Dex and lending platforms',
      trend: '+45%',
    },
    {
      icon: Lightbulb,
      title: lang === 'zh' ? 'NFT 市场' : 'NFT Market',
      description: lang === 'zh' 
        ? '数字艺术和收藏品市场活跃，多个本地NFT项目获得关注' 
        : 'Digital art and collectibles market active, multiple local NFT projects gaining attention',
      trend: '+30%',
    },
    {
      icon: Globe,
      title: lang === 'zh' ? '跨境支付' : 'Cross-border Payments',
      description: lang === 'zh' 
        ? '区块链跨境支付解决方案需求旺盛，特别是亚太地区' 
        : 'High demand for blockchain cross-border payment solutions, especially in Asia-Pacific',
      trend: '+60%',
    },
    {
      icon: Building2,
      title: lang === 'zh' ? '企业应用' : 'Enterprise Applications',
      description: lang === 'zh' 
        ? '大型企业逐步采用区块链技术，供应链和金融领域领先' 
        : 'Large enterprises gradually adopting blockchain technology, supply chain and finance leading',
      trend: '+35%',
    },
  ];

  const risks = [
    {
      icon: AlertTriangle,
      title: lang === 'zh' ? '监管不确定性' : 'Regulatory Uncertainty',
      description: lang === 'zh' 
        ? '虽然总体友好，但监管细节仍在完善中，可能影响运营' 
        : 'Although generally friendly, regulatory details are still being refined, may affect operations',
      level: lang === 'zh' ? '中等' : 'Medium',
    },
    {
      icon: BarChart3,
      title: lang === 'zh' ? '市场波动性' : 'Market Volatility',
      description: lang === 'zh' 
        ? '加密货币市场波动较大，需做好风险管理' 
        : 'Cryptocurrency market is volatile, good risk management required',
      level: lang === 'zh' ? '高' : 'High',
    },
    {
      icon: Users,
      title: lang === 'zh' ? '人才竞争' : 'Talent Competition',
      description: lang === 'zh' 
        ? 'WEB3专业人才供不应求，招聘成本较高' 
        : 'WEB3 professionals in short supply, recruitment costs relatively high',
      level: lang === 'zh' ? '中等' : 'Medium',
    },
    {
      icon: Shield,
      title: lang === 'zh' ? '安全风险' : 'Security Risks',
      description: lang === 'zh' 
        ? '智能合约漏洞和黑客攻击事件时有发生' 
        : 'Smart contract vulnerabilities and hacker attacks occur from time to time',
      level: lang === 'zh' ? '高' : 'High',
    },
  ];

  const adoptionTrends = [
    { year: '2020', adoption: 12 },
    { year: '2021', adoption: 25 },
    { year: '2022', adoption: 38 },
    { year: '2023', adoption: 52 },
    { year: '2024', adoption: 68 },
    { year: '2025 (Projected)', adoption: 85 },
  ];

  const friendlyCountriesWEB3 = [
    { country: '瑞士', flag: '🇨🇭', stance: lang === 'zh' ? '极度友好' : 'Extremely Friendly', score: 98 },
    { country: '新加坡', flag: '🇸🇬', stance: lang === 'zh' ? '非常友好' : 'Very Friendly', score: 95 },
    { country: '新西兰', flag: '🇳🇿', stance: lang === 'zh' ? '非常友好' : 'Very Friendly', score: 90 },
    { country: '德国', flag: '🇩🇪', stance: lang === 'zh' ? '积极支持' : 'Proactive Support', score: 88 },
    { country: '日本', flag: '🇯🇵', stance: lang === 'zh' ? '规范发展' : 'Regulated Development', score: 80 },
    { country: '英国', flag: '🇬🇧', stance: lang === 'zh' ? '积极支持' : 'Proactive Support', score: 85 },
    { country: '美国', flag: '🇺🇸', stance: lang === 'zh' ? '逐步明确' : 'Gradually Clarifying', score: 70 },
    { country: '加拿大', flag: '🇨🇦', stance: lang === 'zh' ? '开放友好' : 'Open & Friendly', score: 85 },
  ];

  return (
    <div className="flex flex-col">
      {/* Hero */}
      <section className="py-20 bg-gradient-to-b from-primary/10 to-transparent">
        <div className="container">
          <div className="max-w-4xl mx-auto text-center">
            <BarChart3 className="h-16 w-16 mx-auto mb-6 text-primary" />
            <h1 className="text-4xl md:text-5xl font-bold mb-6">
              {lang === 'zh' ? 'WEB3与区块链分析' : 'WEB3 & Blockchain Analysis'}
            </h1>
            <p className="text-xl text-muted-foreground mb-8">
              {lang === 'zh' 
                ? '深入了解澳大利亚及全球WEB3发展趋势与机遇' 
                : 'In-depth analysis of WEB3 development trends and opportunities in Australia and globally'}
            </p>
            <Badge className="px-6 py-2 text-lg bg-primary">
              <Shield className="h-4 w-4 mr-2" />
              {australiaAnalysis.overall}
            </Badge>
          </div>
        </div>
      </section>

      {/* Australia Overview */}
      <section className="py-20">
        <div className="container">
          <div className="grid md:grid-cols-2 gap-12 items-center max-w-6xl mx-auto">
            <div>
              <h2 className="text-3xl font-bold mb-6">
                {lang === 'zh' ? '澳大利亚WEB3全景' : 'Australia WEB3 Overview'}
              </h2>
              <p className="text-lg text-muted-foreground mb-8">
                {australiaAnalysis.summary}
              </p>
              <div className="bg-muted/50 rounded-lg p-6">
                <div className="flex justify-between items-center mb-2">
                  <span className="font-semibold">{lang === 'zh' ? '整体评分' : 'Overall Score'}</span>
                  <span className="text-2xl font-bold text-primary">{australiaAnalysis.overallScore}/100</span>
                </div>
                <Progress value={australiaAnalysis.overallScore} className="h-3" />
              </div>
            </div>
            <div className="bg-gradient-to-br from-primary/10 to-teal-500/10 rounded-2xl p-8">
              <h3 className="text-xl font-bold mb-6">
                {lang === 'zh' ? '为什么选择澳大利亚？' : 'Why Australia?'}
              </h3>
              <div className="space-y-4">
                <div className="flex items-start gap-3">
                  <CheckCircle className="h-6 w-6 text-primary mt-0.5 flex-shrink-0" />
                  <div>
                    <h4 className="font-medium">{lang === 'zh' ? '稳定的经济基础' : 'Stable Economic Foundation'}</h4>
                    <p className="text-sm text-muted-foreground">{lang === 'zh' 
                      ? '世界第13大经济体，政治经济环境稳定' 
                      : 'World\'s 13th largest economy, stable political and economic environment'}</p>
                  </div>
                </div>
                <div className="flex items-start gap-3">
                  <CheckCircle className="h-6 w-6 text-primary mt-0.5 flex-shrink-0" />
                  <div>
                    <h4 className="font-medium">{lang === 'zh' ? '友好的监管环境' : 'Friendly Regulatory Environment'}</h4>
                    <p className="text-sm text-muted-foreground">{lang === 'zh' 
                      ? '政府支持创新，同时保护投资者权益' 
                      : 'Government supports innovation while protecting investor rights'}</p>
                  </div>
                </div>
                <div className="flex items-start gap-3">
                  <CheckCircle className="h-6 w-6 text-primary mt-0.5 flex-shrink-0" />
                  <div>
                    <h4 className="font-medium">{lang === 'zh' ? '优越的地理位置' : 'Strategic Location'}</h4>
                    <p className="text-sm text-muted-foreground">{lang === 'zh' 
                      ? '连接亚太地区，是进入区域市场的理想门户' 
                      : 'Connected to Asia-Pacific, ideal gateway to regional markets'}</p>
                  </div>
                </div>
                <div className="flex items-start gap-3">
                  <CheckCircle className="h-6 w-6 text-primary mt-0.5 flex-shrink-0" />
                  <div>
                    <h4 className="font-medium">{lang === 'zh' ? '高素质人才库' : 'High-Quality Talent Pool'}</h4>
                    <p className="text-sm text-muted-foreground">{lang === 'zh' 
                      ? '英语环境，教育水平高，技术人才丰富' 
                      : 'English-speaking environment, high education level, abundant tech talent'}</p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Regulatory Environment */}
      <section className="py-20 bg-muted/50">
        <div className="container">
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-bold mb-4">
              {lang === 'zh' ? '监管环境分析' : 'Regulatory Environment Analysis'}
            </h2>
          </div>
          <div className="grid md:grid-cols-2 gap-6 max-w-6xl mx-auto">
            {regulatoryAspects.map((aspect, index) => (
              <Card key={index}>
                <CardHeader>
                  <div className="flex items-center justify-between mb-4">
                    <div className="flex items-center gap-3">
                      <div className="h-12 w-12 rounded-lg bg-primary/10 flex items-center justify-center">
                        <aspect.icon className="h-6 w-6 text-primary" />
                      </div>
                      <CardTitle>{aspect.title}</CardTitle>
                    </div>
                    <Badge variant="outline">{aspect.status}</Badge>
                  </div>
                  <CardDescription className="text-base">{aspect.description}</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="flex justify-between items-center">
                    <span className="text-sm text-muted-foreground">{lang === 'zh' ? '合规评分' : 'Compliance Score'}</span>
                    <span className="font-bold">{aspect.score}/100</span>
                  </div>
                  <Progress value={aspect.score} className="mt-2 h-2" />
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Opportunities */}
      <section className="py-20">
        <div className="container">
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-bold mb-4">
              {lang === 'zh' ? '市场机会' : 'Market Opportunities'}
            </h2>
          </div>
          <div className="grid md:grid-cols-2 gap-6 max-w-6xl mx-auto">
            {opportunities.map((opp, index) => (
              <Card key={index} className="hover:shadow-lg transition-shadow">
                <CardHeader>
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-3">
                      <div className="h-12 w-12 rounded-lg bg-primary/10 flex items-center justify-center">
                        <opp.icon className="h-6 w-6 text-primary" />
                      </div>
                      <CardTitle>{opp.title}</CardTitle>
                    </div>
                    <Badge className="bg-green-500">{opp.trend}</Badge>
                  </div>
                </CardHeader>
                <CardContent>
                  <p className="text-muted-foreground">{opp.description}</p>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Risks */}
      <section className="py-20 bg-muted/50">
        <div className="container">
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-bold mb-4">
              {lang === 'zh' ? '风险评估' : 'Risk Assessment'}
            </h2>
          </div>
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6 max-w-6xl mx-auto">
            {risks.map((risk, index) => (
              <Card key={index}>
                <CardHeader>
                  <div className="h-10 w-10 rounded-full bg-orange-500/10 flex items-center justify-center mb-3">
                    <risk.icon className="h-5 w-5 text-orange-500" />
                  </div>
                  <CardTitle className="text-lg">{risk.title}</CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-sm text-muted-foreground mb-4">{risk.description}</p>
                  <Badge variant="outline" className={risk.level === (lang === 'zh' ? '高' : 'High') ? 'border-orange-500 text-orange-500' : 'border-yellow-500 text-yellow-500'}>
                    {lang === 'zh' ? '风险等级' : 'Risk Level'}: {risk.level}
                  </Badge>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Adoption Trends */}
      <section className="py-20">
        <div className="container">
          <div className="grid md:grid-cols-2 gap-12 items-center max-w-6xl mx-auto">
            <div>
              <h2 className="text-3xl font-bold mb-6">
                {lang === 'zh' ? '澳大利亚加密货币采用趋势' : 'Australia Cryptocurrency Adoption Trends'}
              </h2>
              <p className="text-lg text-muted-foreground mb-8">
                {lang === 'zh' 
                  ? '澳大利亚加密货币采用率持续增长，预计2025年将超过85%' 
                  : 'Australia\'s cryptocurrency adoption rate continues to grow, projected to exceed 85% by 2025'}
              </p>
              <div className="space-y-4">
                {adoptionTrends.map((trend, index) => (
                  <div key={index} className="flex items-center gap-4">
                    <span className="w-32 text-sm font-medium">{trend.year}</span>
                    <div className="flex-1 bg-muted rounded-full h-6 overflow-hidden">
                      <div 
                        className="bg-primary h-full rounded-full flex items-center justify-end pr-2 transition-all"
                        style={{ width: `${trend.adoption}%` }}
                      >
                        <span className="text-xs text-primary-foreground font-bold">{trend.adoption}%</span>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
            <div className="bg-gradient-to-br from-primary/10 to-teal-500/10 rounded-2xl p-8">
              <h3 className="text-xl font-bold mb-6">
                {lang === 'zh' ? '友好国家WEB3态度排名' : 'Friendly Countries WEB3 Stance Ranking'}
              </h3>
              <div className="space-y-3">
                {friendlyCountriesWEB3.map((country, index) => (
                  <div key={index} className="flex items-center gap-3 bg-background rounded-lg p-3">
                    <span className="text-2xl">{country.flag}</span>
                    <div className="flex-1">
                      <div className="flex justify-between items-center">
                        <span className="font-medium">{country.country}</span>
                        <span className="text-sm text-primary font-bold">{country.score}</span>
                      </div>
                      <p className="text-xs text-muted-foreground">{country.stance}</p>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Conclusion */}
      <section className="py-20 bg-gradient-to-r from-primary to-teal-500 text-white">
        <div className="container text-center">
          <Lightbulb className="h-16 w-16 mx-auto mb-6 opacity-80" />
          <h2 className="text-3xl md:text-4xl font-bold mb-4">
            {lang === 'zh' ? 'EACO的机会' : 'The EACO Opportunity'}
          </h2>
          <p className="text-xl max-w-3xl mx-auto mb-8 opacity-90">
            {lang === 'zh' 
              ? '澳大利亚正处于WEB3发展的黄金期。EACO正是为把握这一历史机遇而创建，我们诚邀您共同参与这场创新革命。'
              : 'Australia is in the golden period of WEB3 development. EACO was created precisely to seize this historic opportunity, and we invite you to participate in this innovation revolution together.'}
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <button className="px-8 py-4 bg-white text-primary rounded-lg font-semibold hover:bg-opacity-90 transition-colors">
              {lang === 'zh' ? '立即加入' : 'Join Now'}
            </button>
            <button className="px-8 py-4 border-2 border-white rounded-lg font-semibold hover:bg-white hover:text-primary transition-colors">
              {lang === 'zh' ? '了解更多投资方案' : 'Learn More About Investment'}
            </button>
          </div>
        </div>
      </section>
    </div>
  );
}
