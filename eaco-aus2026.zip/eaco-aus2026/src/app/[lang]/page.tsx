import Link from 'next/link';
import { 
  ArrowRight, 
  Users, 
  Globe, 
  TrendingUp, 
  Calendar,
  BookOpen,
  Briefcase,
  Building2,
  GraduationCap,
  Award
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { translations } from '@/lib/i18n/translations';
import type { Language } from '@/lib/i18n/translations';

// eslint-disable-next-line @typescript-eslint/no-explicit-any
type Dictionary = any;

export default async function HomePage({
  params,
}: {
  params: Promise<{ lang: string }>;
}) {
  const { lang } = await params;
  const dict = translations as Dictionary;
  const t = (key: string) => dict[key]?.[lang] || key;
  const validLang = (lang === 'zh' ? 'zh' : 'en') as Language;

  const stats = [
    { label: t('stats.members'), value: '500+', icon: Users },
    { label: t('stats.nodes'), value: '12', icon: Globe },
    { label: t('stats.countries'), value: '10', icon: TrendingUp },
    { label: t('stats.events'), value: '150+', icon: Calendar },
  ];

  const features = [
    {
      title: t('handbook.leader.title'),
      description: t('handbook.leader.desc'),
      icon: Building2,
      href: `/${validLang}/handbook#leader`,
    },
    {
      title: t('handbook.onboarding.title'),
      description: t('handbook.onboarding.desc'),
      icon: GraduationCap,
      href: `/${validLang}/handbook#onboarding`,
    },
    {
      title: t('handbook.growth.title'),
      description: t('handbook.growth.desc'),
      icon: Award,
      href: `/${validLang}/handbook#growth`,
    },
    {
      title: t('handbook.ops.title'),
      description: t('handbook.ops.desc'),
      icon: Briefcase,
      href: `/${validLang}/handbook#operations`,
    },
  ];

  return (
    <div className="flex flex-col">
      {/* Hero Section */}
      <section className="relative py-20 lg:py-32 overflow-hidden">
        <div className="container">
          <div className="max-w-4xl mx-auto text-center space-y-8">
            <h1 className="text-4xl md:text-6xl font-bold tracking-tight">
              {t('hero.title')}
            </h1>
            <p className="text-xl md:text-2xl text-muted-foreground">
              {t('hero.subtitle')}
            </p>
            <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
              {t('hero.description')}
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center pt-4">
              <Button asChild size="lg" className="text-lg px-8">
                <Link href={`/${validLang}/investment`}>
                  {t('hero.cta.primary')} <ArrowRight className="ml-2 h-5 w-5" />
                </Link>
              </Button>
              <Button asChild variant="outline" size="lg" className="text-lg px-8">
                <Link href={`/${validLang}/about`}>
                  {t('hero.cta.secondary')}
                </Link>
              </Button>
            </div>
          </div>
        </div>
      </section>

      {/* Stats Section */}
      <section className="py-16 bg-muted/50">
        <div className="container">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-8">
            {stats.map((stat, index) => (
              <div key={index} className="text-center space-y-2">
                <stat.icon className="h-8 w-8 mx-auto text-primary" />
                <div className="text-4xl font-bold">{stat.value}</div>
                <div className="text-sm text-muted-foreground">{stat.label}</div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* About Section */}
      <section className="py-20">
        <div className="container">
          <div className="text-center max-w-3xl mx-auto mb-16">
            <h2 className="text-3xl md:text-4xl font-bold mb-4">{t('about.title')}</h2>
            <div className="grid md:grid-cols-3 gap-8 mt-12">
              <Card>
                <CardHeader>
                  <div className="h-12 w-12 rounded-lg bg-primary/10 flex items-center justify-center mb-4">
                    <TrendingUp className="h-6 w-6 text-primary" />
                  </div>
                  <CardTitle>{t('about.mission.title')}</CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-muted-foreground">{t('about.mission.desc')}</p>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <div className="h-12 w-12 rounded-lg bg-primary/10 flex items-center justify-center mb-4">
                    <Globe className="h-6 w-6 text-primary" />
                  </div>
                  <CardTitle>{t('about.vision.title')}</CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-muted-foreground">{t('about.vision.desc')}</p>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <div className="h-12 w-12 rounded-lg bg-primary/10 flex items-center justify-center mb-4">
                    <Users className="h-6 w-6 text-primary" />
                  </div>
                  <CardTitle>{t('about.values.title')}</CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-muted-foreground">
                    {t('about.values.innovation')} • {t('about.values.collaboration')} • {t('about.values.growth')} • {t('about.values.integrity')}
                  </p>
                </CardContent>
              </Card>
            </div>
          </div>
        </div>
      </section>

      {/* Handbook Preview */}
      <section className="py-20 bg-muted/50">
        <div className="container">
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-bold mb-4">{t('handbook.title')}</h2>
          </div>
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
            {features.map((feature, index) => (
              <Link key={index} href={feature.href}>
                <Card className="h-full hover:shadow-lg transition-shadow cursor-pointer">
                  <CardHeader>
                    <div className="h-12 w-12 rounded-lg bg-primary/10 flex items-center justify-center mb-4">
                      <feature.icon className="h-6 w-6 text-primary" />
                    </div>
                    <CardTitle className="text-lg">{feature.title}</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <p className="text-sm text-muted-foreground">{feature.description}</p>
                  </CardContent>
                </Card>
              </Link>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20">
        <div className="container">
          <div className="bg-gradient-to-r from-primary to-teal-500 rounded-2xl p-12 text-center text-white">
            <h2 className="text-3xl md:text-4xl font-bold mb-4">
              {lang === 'zh' ? '准备好加入我们了吗？' : 'Ready to Join Us?'}
            </h2>
            <p className="text-xl mb-8 opacity-90">
              {lang === 'zh' 
                ? '成为EACO社区的一部分，共同创造更美好的未来'
                : 'Be part of the EACO community and create a better future together'}
            </p>
            <Button asChild size="lg" variant="secondary" className="text-lg">
              <Link href={`/${validLang}/investment`}>
                {t('hero.cta.primary')} <ArrowRight className="ml-2 h-5 w-5" />
              </Link>
            </Button>
          </div>
        </div>
      </section>
    </div>
  );
}
