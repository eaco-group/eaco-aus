import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { 
  Users, 
  Globe, 
  TrendingUp, 
  Heart,
  Target,
  Eye,
  Handshake,
  Lightbulb
} from 'lucide-react';
import { translations } from '@/lib/i18n/translations';
import type { Language } from '@/lib/i18n/translations';

// eslint-disable-next-line @typescript-eslint/no-explicit-any
type Dictionary = any;

export default async function AboutPage({
  params,
}: {
  params: Promise<{ lang: string }>;
}) {
  const { lang } = await params;
  const validLang = (lang === 'zh' ? 'zh' : 'en') as Language;

  const dict = translations as Dictionary;
  const t = (key: string) => dict[key]?.[lang] || key;

  const coreValues = [
    {
      icon: Lightbulb,
      title: lang === 'zh' ? '创新' : 'Innovation',
      description: lang === 'zh' 
        ? '鼓励突破性思维，拥抱新技术和新方法' 
        : 'Encouraging breakthrough thinking and embracing new technologies and methods',
    },
    {
      icon: Handshake,
      title: lang === 'zh' ? '协作' : 'Collaboration',
      description: lang === 'zh' 
        ? '建立跨文化的伙伴关系，共同成长' 
        : 'Building cross-cultural partnerships for mutual growth',
    },
    {
      icon: TrendingUp,
      title: lang === 'zh' ? '成长' : 'Growth',
      description: lang === 'zh' 
        ? '为每个成员提供持续学习和发展的机会' 
        : 'Providing continuous learning and development opportunities for every member',
    },
    {
      icon: Heart,
      title: lang === 'zh' ? '诚信' : 'Integrity',
      description: lang === 'zh' 
        ? '坚持最高的道德标准，透明沟通' 
        : 'Maintaining the highest ethical standards with transparent communication',
    },
  ];

  const milestones = [
    {
      year: lang === 'zh' ? '2023年' : '2023',
      title: lang === 'zh' ? 'EACO Australia 成立' : 'EACO Australia Founded',
      description: lang === 'zh' 
        ? '在悉尼建立第一个城市节点' 
        : 'First urban node established in Sydney',
    },
    {
      year: lang === 'zh' ? '2024 Q1' : '2024 Q1',
      title: lang === 'zh' ? '社区扩展' : 'Community Expansion',
      description: lang === 'zh' 
        ? '墨尔本、布里斯班节点启动' 
        : 'Melbourne and Brisbane nodes launched',
    },
    {
      year: lang === 'zh' ? '2024 Q3' : '2024 Q3',
      title: lang === 'zh' ? '全球战略启动' : 'Global Strategy Launch',
      description: lang === 'zh' 
        ? '制定10国300天扩展计划' 
        : '10-country 300-day expansion plan initiated',
    },
    {
      year: lang === 'zh' ? '2025' : '2025',
      title: lang === 'zh' ? '持续增长' : 'Ongoing Growth',
      description: lang === 'zh' 
        ? '扩展到10个国家，建立区域性中心' 
        : 'Expanding to 10 countries, establishing regional hubs',
    },
  ];

  return (
    <div className="flex flex-col">
      {/* Hero */}
      <section className="py-20 bg-gradient-to-b from-primary/10 to-transparent">
        <div className="container">
          <div className="max-w-4xl mx-auto text-center">
            <h1 className="text-4xl md:text-5xl font-bold mb-6">
              {t('about.title')}
            </h1>
            <p className="text-xl text-muted-foreground">
              {lang === 'zh' 
                ? '了解EACO Australia的使命、愿景和核心价值观'
                : 'Learn about EACO Australia\'s mission, vision, and core values'}
            </p>
          </div>
        </div>
      </section>

      {/* Mission & Vision */}
      <section className="py-20">
        <div className="container">
          <div className="grid md:grid-cols-2 gap-12">
            <Card className="border-2 border-primary/20">
              <CardHeader>
                <div className="h-14 w-14 rounded-lg bg-primary/10 flex items-center justify-center mb-4">
                  <Target className="h-7 w-7 text-primary" />
                </div>
                <CardTitle className="text-2xl">{t('about.mission.title')}</CardTitle>
              </CardHeader>
              <CardContent className="text-lg text-muted-foreground">
                {t('about.mission.desc')}
              </CardContent>
            </Card>

            <Card className="border-2 border-primary/20">
              <CardHeader>
                <div className="h-14 w-14 rounded-lg bg-primary/10 flex items-center justify-center mb-4">
                  <Eye className="h-7 w-7 text-primary" />
                </div>
                <CardTitle className="text-2xl">{t('about.vision.title')}</CardTitle>
              </CardHeader>
              <CardContent className="text-lg text-muted-foreground">
                {t('about.vision.desc')}
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* Core Values */}
      <section className="py-20 bg-muted/50">
        <div className="container">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold mb-4">{t('about.values.title')}</h2>
          </div>
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
            {coreValues.map((value, index) => (
              <Card key={index} className="text-center hover:shadow-lg transition-shadow">
                <CardHeader>
                  <div className="h-14 w-14 rounded-full bg-primary/10 flex items-center justify-center mx-auto mb-4">
                    <value.icon className="h-7 w-7 text-primary" />
                  </div>
                  <CardTitle>{value.title}</CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-sm text-muted-foreground">{value.description}</p>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Timeline */}
      <section className="py-20">
        <div className="container">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold mb-4">
              {lang === 'zh' ? '发展历程' : 'Our Journey'}
            </h2>
          </div>
          <div className="max-w-3xl mx-auto">
            <div className="space-y-8">
              {milestones.map((milestone, index) => (
                <div key={index} className="flex gap-6">
                  <div className="flex-shrink-0 w-24 text-right">
                    <span className="text-lg font-bold text-primary">{milestone.year}</span>
                  </div>
                  <div className="flex-shrink-0 relative">
                    <div className="h-4 w-4 rounded-full bg-primary mt-2" />
                    {index < milestones.length - 1 && (
                      <div className="absolute top-4 left-1/2 transform -translate-x-1/2 w-0.5 h-full bg-border -z-10" />
                    )}
                  </div>
                  <div className="flex-1 pb-8">
                    <h3 className="text-xl font-semibold mb-2">{milestone.title}</h3>
                    <p className="text-muted-foreground">{milestone.description}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* Stats */}
      <section className="py-20 bg-gradient-to-r from-primary to-teal-500 text-white">
        <div className="container">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-8">
            <div className="text-center">
              <Users className="h-10 w-10 mx-auto mb-4 opacity-80" />
              <div className="text-5xl font-bold mb-2">500+</div>
              <div className="opacity-80">{t('stats.members')}</div>
            </div>
            <div className="text-center">
              <Globe className="h-10 w-10 mx-auto mb-4 opacity-80" />
              <div className="text-5xl font-bold mb-2">12</div>
              <div className="opacity-80">{t('stats.nodes')}</div>
            </div>
            <div className="text-center">
              <TrendingUp className="h-10 w-10 mx-auto mb-4 opacity-80" />
              <div className="text-5xl font-bold mb-2">10</div>
              <div className="opacity-80">{t('stats.countries')}</div>
            </div>
            <div className="text-center">
              <Heart className="h-10 w-10 mx-auto mb-4 opacity-80" />
              <div className="text-5xl font-bold mb-2">150+</div>
              <div className="opacity-80">{t('stats.events')}</div>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}
