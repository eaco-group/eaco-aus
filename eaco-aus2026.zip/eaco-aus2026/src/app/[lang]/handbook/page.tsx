import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { 
  Building2, 
  GraduationCap, 
  TrendingUp, 
  BookOpen,
  CheckCircle,
  Users,
  Target,
  Lightbulb,
  Shield,
  Calendar,
  Award,
  Globe
} from 'lucide-react';
import { translations } from '@/lib/i18n/translations';
import type { Language } from '@/lib/i18n/translations';

export default async function HandbookPage({
  params,
}: {
  params: Promise<{ lang: string }>;
}) {
  const { lang } = await params;
  const validLang = (lang === 'zh' ? 'zh' : 'en') as Language;

  return (
    <div className="flex flex-col">
      {/* Hero */}
      <section className="py-20 bg-gradient-to-b from-primary/10 to-transparent">
        <div className="container">
          <div className="max-w-4xl mx-auto text-center">
            <BookOpen className="h-16 w-16 mx-auto mb-6 text-primary" />
            <h1 className="text-4xl md:text-5xl font-bold mb-6">
              {lang === 'zh' ? '训练手册' : 'Training Manuals'}
            </h1>
            <p className="text-xl text-muted-foreground">
              {lang === 'zh' 
                ? '完整的培训资源库，帮助您成为优秀的EACO成员和领导者'
                : 'Complete training resource library to help you become an outstanding EACO member and leader'}
            </p>
          </div>
        </div>
      </section>

      {/* Content */}
      <section className="py-12">
        <div className="container">
          <Tabs defaultValue="leader" className="space-y-8">
            <TabsList className="grid w-full grid-cols-2 lg:grid-cols-4 h-auto">
              <TabsTrigger value="leader" className="py-3">
                <Building2 className="h-4 w-4 mr-2" />
                {lang === 'zh' ? 'Leader' : 'Leader'}
              </TabsTrigger>
              <TabsTrigger value="onboarding" className="py-3">
                <GraduationCap className="h-4 w-4 mr-2" />
                {lang === 'zh' ? 'Onboarding' : 'Onboarding'}
              </TabsTrigger>
              <TabsTrigger value="growth" className="py-3">
                <TrendingUp className="h-4 w-4 mr-2" />
                {lang === 'zh' ? 'Growth' : 'Growth'}
              </TabsTrigger>
              <TabsTrigger value="operations" className="py-3">
                <Globe className="h-4 w-4 mr-2" />
                {lang === 'zh' ? 'Operations' : 'Operations'}
              </TabsTrigger>
            </TabsList>

            {/* Leader Handbook */}
            <TabsContent value="leader" id="leader">
              <Card className="border-2 border-primary/20">
                <CardHeader>
                  <CardTitle className="text-3xl flex items-center gap-3">
                    <Building2 className="h-8 w-8 text-primary" />
                    {lang === 'zh' 
                      ? '澳大利亚 EACO 城市节点 Leader 训练手册' 
                      : 'Australia EACO Urban Node Leader Training Handbook'}
                  </CardTitle>
                  <CardDescription className="text-lg">
                    {lang === 'zh' 
                      ? '专为城市节点负责人设计的全面指南'
                      : 'Comprehensive guide designed for urban node leaders'}
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-8">
                  {/* Section 1 */}
                  <div className="space-y-4">
                    <h3 className="text-2xl font-bold flex items-center gap-2">
                      <Target className="h-6 w-6 text-primary" />
                      {lang === 'zh' ? '第一章：Leader的角色与职责' : 'Chapter 1: Role and Responsibilities of a Leader'}
                    </h3>
                    <div className="bg-muted/50 rounded-lg p-6 space-y-3">
                      <p className="font-semibold">{lang === 'zh' ? '核心职责：' : 'Core Responsibilities:'}</p>
                      <ul className="space-y-2 ml-6">
                        <li className="flex items-start gap-2">
                          <CheckCircle className="h-5 w-5 text-primary mt-0.5 flex-shrink-0" />
                          <span>{lang === 'zh' 
                            ? '管理城市节点的日常运营和发展战略' 
                            : 'Manage daily operations and development strategy of the urban node'}</span>
                        </li>
                        <li className="flex items-start gap-2">
                          <CheckCircle className="h-5 w-5 text-primary mt-0.5 flex-shrink-0" />
                          <span>{lang === 'zh' 
                            ? '招募、培训和指导志愿者团队' 
                            : 'Recruit, train, and mentor volunteer teams'}</span>
                        </li>
                        <li className="flex items-start gap-2">
                          <CheckCircle className="h-5 w-5 text-primary mt-0.5 flex-shrink-0" />
                          <span>{lang === 'zh' 
                            ? '与总部和其他节点保持密切沟通协作' 
                            : 'Maintain close communication and collaboration with headquarters and other nodes'}</span>
                        </li>
                        <li className="flex items-start gap-2">
                          <CheckCircle className="h-5 w-5 text-primary mt-0.5 flex-shrink-0" />
                          <span>{lang === 'zh' 
                            ? '制定并实现季度和年度目标' 
                            : 'Develop and achieve quarterly and annual goals'}</span>
                        </li>
                        <li className="flex items-start gap-2">
                          <CheckCircle className="h-5 w-5 text-primary mt-0.5 flex-shrink-0" />
                          <span>{lang === 'zh' 
                            ? '组织线下线上活动，提升社区活跃度' 
                            : 'Organize offline and online events to enhance community activity'}</span>
                        </li>
                      </ul>
                    </div>
                  </div>

                  {/* Section 2 */}
                  <div className="space-y-4">
                    <h3 className="text-2xl font-bold flex items-center gap-2">
                      <Users className="h-6 w-6 text-primary" />
                      {lang === 'zh' ? '第二章：团队建设与管理' : 'Chapter 2: Team Building and Management'}
                    </h3>
                    <div className="bg-muted/50 rounded-lg p-6 space-y-3">
                      <p className="font-semibold">{lang === 'zh' ? '团队结构建议：' : 'Recommended Team Structure:'}</p>
                      <div className="grid md:grid-cols-3 gap-4">
                        <div className="bg-background rounded-lg p-4">
                          <h4 className="font-semibold mb-2">{lang === 'zh' ? '核心团队 (3-5人)' : 'Core Team (3-5 people)'}</h4>
                          <p className="text-sm text-muted-foreground">{lang === 'zh' 
                            ? '负责决策、战略规划和重要事项执行' 
                            : 'Responsible for decisions, strategic planning, and execution of important matters'}</p>
                        </div>
                        <div className="bg-background rounded-lg p-4">
                          <h4 className="font-semibold mb-2">{lang === 'zh' ? '执行团队 (5-10人)' : 'Execution Team (5-10 people)'}</h4>
                          <p className="text-sm text-muted-foreground">{lang === 'zh' 
                            ? '负责具体项目和活动执行' 
                            : 'Responsible for specific project and activity execution'}</p>
                        </div>
                        <div className="bg-background rounded-lg p-4">
                          <h4 className="font-semibold mb-2">{lang === 'zh' ? '志愿者库 (20+人)' : 'Volunteer Pool (20+ people)'}</h4>
                          <p className="text-sm text-muted-foreground">{lang === 'zh' 
                            ? '提供灵活的人力支持' 
                            : 'Provide flexible manpower support'}</p>
                        </div>
                      </div>
                    </div>
                  </div>

                  {/* Section 3 */}
                  <div className="space-y-4">
                    <h3 className="text-2xl font-bold flex items-center gap-2">
                      <Lightbulb className="h-6 w-6 text-primary" />
                      {lang === 'zh' ? '第三章：领导力发展' : 'Chapter 3: Leadership Development'}
                    </h3>
                    <div className="bg-muted/50 rounded-lg p-6">
                      <p className="mb-4">{lang === 'zh' 
                        ? '作为Leader，你需要不断提升以下关键领导力技能：' 
                        : 'As a Leader, you need to continuously improve the following key leadership skills:'}</p>
                      <div className="grid md:grid-cols-2 gap-4">
                        <div className="flex items-center gap-3 bg-background rounded-lg p-3">
                          <div className="h-10 w-10 rounded-full bg-primary/10 flex items-center justify-center">
                            <span className="font-bold text-primary">1</span>
                          </div>
                          <div>
                            <h4 className="font-semibold">{lang === 'zh' ? '战略思维' : 'Strategic Thinking'}</h4>
                            <p className="text-sm text-muted-foreground">{lang === 'zh' 
                              ? '制定长期发展规划' 
                              : 'Develop long-term development plans'}</p>
                          </div>
                        </div>
                        <div className="flex items-center gap-3 bg-background rounded-lg p-3">
                          <div className="h-10 w-10 rounded-full bg-primary/10 flex items-center justify-center">
                            <span className="font-bold text-primary">2</span>
                          </div>
                          <div>
                            <h4 className="font-semibold">{lang === 'zh' ? '沟通能力' : 'Communication Skills'}</h4>
                            <p className="text-sm text-muted-foreground">{lang === 'zh' 
                              ? '清晰有效地传达信息' 
                              : 'Communicate information clearly and effectively'}</p>
                          </div>
                        </div>
                        <div className="flex items-center gap-3 bg-background rounded-lg p-3">
                          <div className="h-10 w-10 rounded-full bg-primary/10 flex items-center justify-center">
                            <span className="font-bold text-primary">3</span>
                          </div>
                          <div>
                            <h4 className="font-semibold">{lang === 'zh' ? '团队激励' : 'Team Motivation'}</h4>
                            <p className="text-sm text-muted-foreground">{lang === 'zh' 
                              ? '激发团队潜能和热情' 
                              : 'Inspire team potential and enthusiasm'}</p>
                          </div>
                        </div>
                        <div className="flex items-center gap-3 bg-background rounded-lg p-3">
                          <div className="h-10 w-10 rounded-full bg-primary/10 flex items-center justify-center">
                            <span className="font-bold text-primary">4</span>
                          </div>
                          <div>
                            <h4 className="font-semibold">{lang === 'zh' ? '问题解决' : 'Problem Solving'}</h4>
                            <p className="text-sm text-muted-foreground">{lang === 'zh' 
                              ? '快速应对各种挑战' 
                              : 'Quickly respond to various challenges'}</p>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>

                  {/* Section 4 */}
                  <div className="space-y-4">
                    <h3 className="text-2xl font-bold flex items-center gap-2">
                      <Calendar className="h-6 w-6 text-primary" />
                      {lang === 'zh' ? '第四章：目标设定与追踪' : 'Chapter 4: Goal Setting and Tracking'}
                    </h3>
                    <div className="bg-muted/50 rounded-lg p-6">
                      <p className="mb-4">{lang === 'zh' 
                        ? '使用SMART原则设定目标：' 
                        : 'Set goals using the SMART principle:'}</p>
                      <div className="space-y-3">
                        <div className="flex items-center gap-3 bg-background rounded-lg p-3">
                          <Shield className="h-8 w-8 text-primary" />
                          <div>
                            <h4 className="font-semibold">S - Specific ({lang === 'zh' ? '具体' : 'Specific'})</h4>
                            <p className="text-sm text-muted-foreground">{lang === 'zh' 
                              ? '明确要达成的具体成果' 
                              : 'Clearly define the specific results to be achieved'}</p>
                          </div>
                        </div>
                        <div className="flex items-center gap-3 bg-background rounded-lg p-3">
                          <Shield className="h-8 w-8 text-primary" />
                          <div>
                            <h4 className="font-semibold">M - Measurable ({lang === 'zh' ? '可衡量' : 'Measurable'})</h4>
                            <p className="text-sm text-muted-foreground">{lang === 'zh' 
                              ? '设定可量化评估的标准' 
                              : 'Set quantifiable evaluation criteria'}</p>
                          </div>
                        </div>
                        <div className="flex items-center gap-3 bg-background rounded-lg p-3">
                          <Shield className="h-8 w-8 text-primary" />
                          <div>
                            <h4 className="font-semibold">A - Achievable ({lang === 'zh' ? '可实现' : 'Achievable'})</h4>
                            <p className="text-sm text-muted-foreground">{lang === 'zh' 
                              ? '确保目标具有挑战性但可达成' 
                              : 'Ensure goals are challenging but achievable'}</p>
                          </div>
                        </div>
                        <div className="flex items-center gap-3 bg-background rounded-lg p-3">
                          <Shield className="h-8 w-8 text-primary" />
                          <div>
                            <h4 className="font-semibold">R - Relevant ({lang === 'zh' ? '相关' : 'Relevant'})</h4>
                            <p className="text-sm text-muted-foreground">{lang === 'zh' 
                              ? '目标与整体战略保持一致' 
                              : 'Goals align with overall strategy'}</p>
                          </div>
                        </div>
                        <div className="flex items-center gap-3 bg-background rounded-lg p-3">
                          <Shield className="h-8 w-8 text-primary" />
                          <div>
                            <h4 className="font-semibold">T - Time-bound ({lang === 'zh' ? '有时限' : 'Time-bound'})</h4>
                            <p className="text-sm text-muted-foreground">{lang === 'zh' 
                              ? '设定明确的完成时间节点' 
                              : 'Set clear completion deadlines'}</p>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>

            {/* Onboarding Kit */}
            <TabsContent value="onboarding" id="onboarding">
              <Card className="border-2 border-primary/20">
                <CardHeader>
                  <CardTitle className="text-3xl flex items-center gap-3">
                    <GraduationCap className="h-8 w-8 text-primary" />
                    {lang === 'zh' 
                      ? '澳大利亚 EACO 志愿者 Onboarding 套件' 
                      : 'Australia EACO Volunteer Onboarding Kit'}
                  </CardTitle>
                  <CardDescription className="text-lg">
                    {lang === 'zh' 
                      ? '新志愿者入门指南，可直接发给新人'
                      : 'New volunteer onboarding guide, ready to send to newcomers'}
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-8">
                  {/* Welcome Message */}
                  <div className="bg-gradient-to-r from-primary/10 to-teal-500/10 rounded-lg p-8 text-center">
                    <h3 className="text-2xl font-bold mb-4">
                      {lang === 'zh' ? '欢迎加入EACO！' : 'Welcome to EACO!'}
                    </h3>
                    <p className="text-lg text-muted-foreground">
                      {lang === 'zh' 
                        ? '感谢您决定成为EACO社区的一员。我们很高兴有您这样充满热情和才华的人加入我们的大家庭。'
                        : 'Thank you for deciding to become part of the EACO community. We are delighted to have someone as passionate and talented as you join our family.'}
                    </p>
                  </div>

                  {/* Getting Started Checklist */}
                  <div className="space-y-4">
                    <h3 className="text-2xl font-bold">{lang === 'zh' ? '第一周任务清单' : 'First Week Checklist'}</h3>
                    <div className="grid md:grid-cols-2 gap-4">
                      <div className="bg-muted/50 rounded-lg p-6">
                        <h4 className="font-semibold mb-4 flex items-center gap-2">
                          <CheckCircle className="h-5 w-5 text-primary" />
                          {lang === 'zh' ? '第一天' : 'Day 1'}
                        </h4>
                        <ul className="space-y-2 text-sm">
                          <li>{lang === 'zh' ? '阅读EACO使命和愿景' : 'Read EACO mission and vision'}</li>
                          <li>{lang === 'zh' ? '完成会员注册' : 'Complete member registration'}</li>
                          <li>{lang === 'zh' ? '加入社区Discord/Slack' : 'Join community Discord/Slack'}</li>
                          <li>{lang === 'zh' ? '认识您的导师' : 'Meet your mentor'}</li>
                        </ul>
                      </div>
                      <div className="bg-muted/50 rounded-lg p-6">
                        <h4 className="font-semibold mb-4 flex items-center gap-2">
                          <CheckCircle className="h-5 w-5 text-primary" />
                          {lang === 'zh' ? '第二-三天' : 'Days 2-3'}
                        </h4>
                        <ul className="space-y-2 text-sm">
                          <li>{lang === 'zh' ? '完成在线培训模块1-3' : 'Complete online training modules 1-3'}</li>
                          <li>{lang === 'zh' ? '了解社区规则和行为准则' : 'Understand community rules and code of conduct'}</li>
                          <li>{lang === 'zh' ? '参加第一次社区例会' : 'Attend first community meeting'}</li>
                        </ul>
                      </div>
                      <div className="bg-muted/50 rounded-lg p-6">
                        <h4 className="font-semibold mb-4 flex items-center gap-2">
                          <CheckCircle className="h-5 w-5 text-primary" />
                          {lang === 'zh' ? '第四-五天' : 'Days 4-5'}
                        </h4>
                        <ul className="space-y-2 text-sm">
                          <li>{lang === 'zh' ? '完成培训模块4-6' : 'Complete training modules 4-6'}</li>
                          <li>{lang === 'zh' ? '选择一个感兴趣的项目组' : 'Choose a project group of interest'}</li>
                          <li>{lang === 'zh' ? '与项目负责人进行一对一交流' : 'Have one-on-one with project lead'}</li>
                        </ul>
                      </div>
                      <div className="bg-muted/50 rounded-lg p-6">
                        <h4 className="font-semibold mb-4 flex items-center gap-2">
                          <CheckCircle className="h-5 w-5 text-primary" />
                          {lang === 'zh' ? '周末' : 'Weekend'}
                        </h4>
                        <ul className="space-y-2 text-sm">
                          <li>{lang === 'zh' ? '回顾本周学习内容' : 'Review week 1 learning content'}</li>
                          <li>{lang === 'zh' ? '准备第一份贡献计划' : 'Prepare first contribution plan'}</li>
                          <li>{lang === 'zh' ? '与导师讨论发展方向' : 'Discuss development direction with mentor'}</li>
                        </ul>
                      </div>
                    </div>
                  </div>

                  {/* Role Descriptions */}
                  <div className="space-y-4">
                    <h3 className="text-2xl font-bold">{lang === 'zh' ? '角色说明' : 'Role Descriptions'}</h3>
                    <div className="grid md:grid-cols-3 gap-4">
                      <Card>
                        <CardHeader>
                          <CardTitle className="text-lg">{lang === 'zh' ? '活动志愿者' : 'Event Volunteer'}</CardTitle>
                        </CardHeader>
                        <CardContent>
                          <p className="text-sm text-muted-foreground">{lang === 'zh' 
                            ? '协助组织线下和线上活动，包括场地准备、签到、引导等' 
                            : 'Assist in organizing offline and online events, including venue preparation, check-in, guidance, etc.'}</p>
                        </CardContent>
                      </Card>
                      <Card>
                        <CardHeader>
                          <CardTitle className="text-lg">{lang === 'zh' ? '内容创作者' : 'Content Creator'}</CardTitle>
                        </CardHeader>
                        <CardContent>
                          <p className="text-sm text-muted-foreground">{lang === 'zh' 
                            ? '创作文章、视频、社交媒体内容，传播EACO理念' 
                            : 'Create articles, videos, social media content to spread EACO philosophy'}</p>
                        </CardContent>
                      </Card>
                      <Card>
                        <CardHeader>
                          <CardTitle className="text-lg">{lang === 'zh' ? '社群运营' : 'Community Operations'}</CardTitle>
                        </CardHeader>
                        <CardContent>
                          <p className="text-sm text-muted-foreground">{lang === 'zh' 
                            ? '管理社区群组，维护秩序，促进成员互动' 
                            : 'Manage community groups, maintain order, promote member interaction'}</p>
                        </CardContent>
                      </Card>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>

            {/* Growth System */}
            <TabsContent value="growth" id="growth">
              <Card className="border-2 border-primary/20">
                <CardHeader>
                  <CardTitle className="text-3xl flex items-center gap-3">
                    <TrendingUp className="h-8 w-8 text-primary" />
                    {lang === 'zh' 
                      ? '澳大利亚 EACO 志愿者 1-6 个月成长体系' 
                      : 'Australia EACO Volunteer 1-6 Month Growth System'}
                  </CardTitle>
                  <CardDescription className="text-lg">
                    {lang === 'zh' 
                      ? '系统化的成长路径，帮助志愿者从入门到成为核心成员'
                      : 'Systematic growth path helping volunteers progress from entry to core membership'}
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-8">
                  {/* Month 1 */}
                  <div className="space-y-4">
                    <div className="flex items-center gap-3">
                      <div className="h-12 w-12 rounded-full bg-primary text-white flex items-center justify-center font-bold text-xl">
                        1
                      </div>
                      <h3 className="text-2xl font-bold">{lang === 'zh' ? '第一个月：基础建设期' : 'Month 1: Foundation Building'}</h3>
                    </div>
                    <div className="bg-muted/50 rounded-lg p-6">
                      <div className="grid md:grid-cols-3 gap-4 mb-4">
                        <div>
                          <h4 className="font-semibold mb-2">{lang === 'zh' ? '学习目标' : 'Learning Objectives'}</h4>
                          <ul className="text-sm space-y-1 text-muted-foreground">
                            <li>{lang === 'zh' ? '了解EACO使命愿景' : 'Understand EACO mission & vision'}</li>
                            <li>{lang === 'zh' ? '熟悉组织架构' : 'Familiarize with organization structure'}</li>
                            <li>{lang === 'zh' ? '掌握基础工具使用' : 'Master basic tool usage'}</li>
                          </ul>
                        </div>
                        <div>
                          <h4 className="font-semibold mb-2">{lang === 'zh' ? '实践任务' : 'Practical Tasks'}</h4>
                          <ul className="text-sm space-y-1 text-muted-foreground">
                            <li>{lang === 'zh' ? '参加2次社群活动' : 'Attend 2 community events'}</li>
                            <li>{lang === 'zh' ? '完成入门培训' : 'Complete onboarding training'}</li>
                            <li>{lang === 'zh' ? '结识5位成员' : 'Meet 5 members'}</li>
                          </ul>
                        </div>
                        <div>
                          <h4 className="font-semibold mb-2">{lang === 'zh' ? '成功指标' : 'Success Metrics'}</h4>
                          <ul className="text-sm space-y-1 text-muted-foreground">
                            <li>{lang === 'zh' ? '完成培训证书' : 'Training certificate completed'}</li>
                            <li>{lang === 'zh' ? '活跃度>50%' : 'Activity >50%'}</li>
                            <li>{lang === 'zh' ? '获得导师认可' : 'Mentor recognition'}</li>
                          </ul>
                        </div>
                      </div>
                    </div>
                  </div>

                  {/* Month 2-3 */}
                  <div className="space-y-4">
                    <div className="flex items-center gap-3">
                      <div className="h-12 w-12 rounded-full bg-primary text-white flex items-center justify-center font-bold text-xl">
                        2-3
                      </div>
                      <h3 className="text-2xl font-bold">{lang === 'zh' ? '第二-三个月：能力提升期' : 'Months 2-3: Capability Enhancement'}</h3>
                    </div>
                    <div className="bg-muted/50 rounded-lg p-6">
                      <div className="grid md:grid-cols-3 gap-4 mb-4">
                        <div>
                          <h4 className="font-semibold mb-2">{lang === 'zh' ? '学习目标' : 'Learning Objectives'}</h4>
                          <ul className="text-sm space-y-1 text-muted-foreground">
                            <li>{lang === 'zh' ? '深入了解WEB3知识' : 'Deep dive into WEB3 knowledge'}</li>
                            <li>{lang === 'zh' ? '掌握项目管理基础' : 'Master project management basics'}</li>
                            <li>{lang === 'zh' ? '提升沟通协作能力' : 'Improve communication skills'}</li>
                          </ul>
                        </div>
                        <div>
                          <h4 className="font-semibold mb-2">{lang === 'zh' ? '实践任务' : 'Practical Tasks'}</h4>
                          <ul className="text-sm space-y-1 text-muted-foreground">
                            <li>{lang === 'zh' ? '主导1个小项目' : 'Lead 1 small project'}</li>
                            <li>{lang === 'zh' ? '组织1次小组讨论' : 'Organize 1 group discussion'}</li>
                            <li>{lang === 'zh' ? '贡献3篇内容' : 'Contribute 3 pieces of content'}</li>
                          </ul>
                        </div>
                        <div>
                          <h4 className="font-semibold mb-2">{lang === 'zh' ? '成功指标' : 'Success Metrics'}</h4>
                          <ul className="text-sm space-y-1 text-muted-foreground">
                            <li>{lang === 'zh' ? '项目评分>4/5' : 'Project rating >4/5'}</li>
                            <li>{lang === 'zh' ? '团队反馈优秀' : 'Excellent team feedback'}</li>
                            <li>{lang === 'zh' ? '准备晋升候选' : 'Ready for promotion candidate'}</li>
                          </ul>
                        </div>
                      </div>
                    </div>
                  </div>

                  {/* Month 4-6 */}
                  <div className="space-y-4">
                    <div className="flex items-center gap-3">
                      <div className="h-12 w-12 rounded-full bg-primary text-white flex items-center justify-center font-bold text-xl">
                        4-6
                      </div>
                      <h3 className="text-2xl font-bold">{lang === 'zh' ? '第四-六个月：领导发展期' : 'Months 4-6: Leadership Development'}</h3>
                    </div>
                    <div className="bg-muted/50 rounded-lg p-6">
                      <div className="grid md:grid-cols-3 gap-4 mb-4">
                        <div>
                          <h4 className="font-semibold mb-2">{lang === 'zh' ? '学习目标' : 'Learning Objectives'}</h4>
                          <ul className="text-sm space-y-1 text-muted-foreground">
                            <li>{lang === 'zh' ? '学习团队管理' : 'Learn team management'}</li>
                            <li>{lang === 'zh' ? '培养战略思维' : 'Develop strategic thinking'}</li>
                            <li>{lang === 'zh' ? '建立个人品牌' : 'Build personal brand'}</li>
                          </ul>
                        </div>
                        <div>
                          <h4 className="font-semibold mb-2">{lang === 'zh' ? '实践任务' : 'Practical Tasks'}</h4>
                          <ul className="text-sm space-y-1 text-muted-foreground">
                            <li>{lang === 'zh' ? '带领3-5人小组' : 'Lead team of 3-5 people'}</li>
                            <li>{lang === 'zh' ? '独立组织活动' : 'Independently organize events'}</li>
                            <li>{lang === 'zh' ? '指导新人' : 'Mentor newcomers'}</li>
                          </ul>
                        </div>
                        <div>
                          <h4 className="font-semibold mb-2">{lang === 'zh' ? '成功指标' : 'Success Metrics'}</h4>
                          <ul className="text-sm space-y-1 text-muted-foreground">
                            <li>{lang === 'zh' ? '晋升为副Leader' : 'Promoted to Assistant Leader'}</li>
                            <li>{lang === 'zh' ? '团队满意度>90%' : 'Team satisfaction >90%'}</li>
                            <li>{lang === 'zh' ? '获得专业认证' : 'Obtained professional certification'}</li>
                          </ul>
                        </div>
                      </div>
                    </div>
                  </div>

                  {/* Badge System */}
                  <div className="bg-gradient-to-r from-primary/10 to-teal-500/10 rounded-lg p-8">
                    <h3 className="text-2xl font-bold mb-6 flex items-center gap-2">
                      <Award className="h-8 w-8 text-primary" />
                      {lang === 'zh' ? '成就徽章体系' : 'Achievement Badge System'}
                    </h3>
                    <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                      <div className="text-center">
                        <div className="h-16 w-16 rounded-full bg-yellow-400/20 flex items-center justify-center mx-auto mb-2">
                          <span className="text-2xl">🌟</span>
                        </div>
                        <p className="text-sm font-medium">{lang === 'zh' ? '新星' : 'New Star'}</p>
                      </div>
                      <div className="text-center">
                        <div className="h-16 w-16 rounded-full bg-blue-400/20 flex items-center justify-center mx-auto mb-2">
                          <span className="text-2xl">🚀</span>
                        </div>
                        <p className="text-sm font-medium">{lang === 'zh' ? '进取' : 'Go-Getter'}</p>
                      </div>
                      <div className="text-center">
                        <div className="h-16 w-16 rounded-full bg-purple-400/20 flex items-center justify-center mx-auto mb-2">
                          <span className="text-2xl">💎</span>
                        </div>
                        <p className="text-sm font-medium">{lang === 'zh' ? '钻石' : 'Diamond'}</p>
                      </div>
                      <div className="text-center">
                        <div className="h-16 w-16 rounded-full bg-red-400/20 flex items-center justify-center mx-auto mb-2">
                          <span className="text-2xl">👑</span>
                        </div>
                        <p className="text-sm font-medium">{lang === 'zh' ? '领袖' : 'Leader'}</p>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>

            {/* Operations Guide */}
            <TabsContent value="operations" id="operations">
              <Card className="border-2 border-primary/20">
                <CardHeader>
                  <CardTitle className="text-3xl flex items-center gap-3">
                    <Globe className="h-8 w-8 text-primary" />
                    {lang === 'zh' 
                      ? '澳大利亚 EACO 运营指南（全球可复制）' 
                      : 'Australia EACO Operations Guide (Globally Replicable)'}
                  </CardTitle>
                  <CardDescription className="text-lg">
                    {lang === 'zh' 
                      ? '标准化运营流程，确保全球各地节点的一致性'
                      : 'Standardized operating procedures ensuring consistency across all nodes globally'}
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-8">
                  {/* Standard Operating Procedures */}
                  <div className="space-y-4">
                    <h3 className="text-2xl font-bold">{lang === 'zh' ? '标准运营流程 (SOP)' : 'Standard Operating Procedures (SOP)'}</h3>
                    
                    <div className="space-y-4">
                      <div className="bg-muted/50 rounded-lg p-6">
                        <h4 className="font-semibold mb-3 flex items-center gap-2">
                          <span className="h-8 w-8 rounded-full bg-primary text-white flex items-center justify-center font-bold">1</span>
                          {lang === 'zh' ? '节点启动流程' : 'Node Startup Process'}
                        </h4>
                        <div className="grid md:grid-cols-2 gap-4">
                          <div>
                            <h5 className="font-medium mb-2">{lang === 'zh' ? '前期准备' : 'Pre-Setup'}</h5>
                            <ul className="text-sm space-y-1 text-muted-foreground">
                              <li>{lang === 'zh' ? '市场调研和需求分析' : 'Market research and needs analysis'}</li>
                              <li>{lang === 'zh' ? '核心团队招募（3-5人）' : 'Core team recruitment (3-5 people)'}</li>
                              <li>{lang === 'zh' ? '资源筹备和预算制定' : 'Resource preparation and budget planning'}</li>
                            </ul>
                          </div>
                          <div>
                            <h5 className="font-medium mb-2">{lang === 'zh' ? '执行步骤' : 'Execution Steps'}</h5>
                            <ul className="text-sm space-y-1 text-muted-foreground">
                              <li>{lang === 'zh' ? '提交节点申请表格' : 'Submit node application form'}</li>
                              <li>{lang === 'zh' ? '完成总部培训认证' : 'Complete headquarters training certification'}</li>
                              <li>{lang === 'zh' ? '举办启动仪式' : 'Hold launch ceremony'}</li>
                            </ul>
                          </div>
                        </div>
                      </div>

                      <div className="bg-muted/50 rounded-lg p-6">
                        <h4 className="font-semibold mb-3 flex items-center gap-2">
                          <span className="h-8 w-8 rounded-full bg-primary text-white flex items-center justify-center font-bold">2</span>
                          {lang === 'zh' ? '活动组织流程' : 'Event Organization Process'}
                        </h4>
                        <div className="space-y-3">
                          <div className="flex items-center gap-3">
                            <span className="font-semibold text-primary w-20">{lang === 'zh' ? '计划' : 'Plan'}</span>
                            <span className="text-sm">{lang === 'zh' 
                              ? '确定活动主题、时间和预算' 
                              : 'Define event theme, time and budget'}</span>
                          </div>
                          <div className="flex items-center gap-3">
                            <span className="font-semibold text-primary w-20">{lang === 'zh' ? '准备' : 'Prepare'}</span>
                            <span className="text-sm">{lang === 'zh' 
                              ? '场地、物资、人员、宣传' 
                              : 'Venue, materials, personnel, promotion'}</span>
                          </div>
                          <div className="flex items-center gap-3">
                            <span className="font-semibold text-primary w-20">{lang === 'zh' ? '执行' : 'Execute'}</span>
                            <span className="text-sm">{lang === 'zh' 
                              ? '签到、现场管理、互动环节' 
                              : 'Check-in, on-site management, interactive sessions'}</span>
                          </div>
                          <div className="flex items-center gap-3">
                            <span className="font-semibold text-primary w-20">{lang === 'zh' ? '复盘' : 'Review'}</span>
                            <span className="text-sm">{lang === 'zh' 
                              ? '收集反馈、总结经验、文档归档' 
                              : 'Collect feedback, summarize experience, archive documents'}</span>
                          </div>
                        </div>
                      </div>

                      <div className="bg-muted/50 rounded-lg p-6">
                        <h4 className="font-semibold mb-3 flex items-center gap-2">
                          <span className="h-8 w-8 rounded-full bg-primary text-white flex items-center justify-center font-bold">3</span>
                          {lang === 'zh' ? '成员管理流程' : 'Member Management Process'}</h4>
                        <div className="grid md:grid-cols-2 gap-4">
                          <div>
                            <h5 className="font-medium mb-2">{lang === 'zh' ? '招募' : 'Recruitment'}</h5>
                            <ul className="text-sm space-y-1 text-muted-foreground">
                              <li>{lang === 'zh' ? '发布招募信息' : 'Publish recruitment information'}</li>
                              <li>{lang === 'zh' ? '面试和筛选' : 'Interview and screen'}</li>
                              <li>{lang === 'zh' ? '发送录用通知' : 'Send offer letters'}</li>
                            </ul>
                          </div>
                          <div>
                            <h5 className="font-medium mb-2">{lang === 'zh' ? '发展' : 'Development'}</h5>
                            <ul className="text-sm space-y-1 text-muted-foreground">
                              <li>{lang === 'zh' ? '入职培训' : 'Onboarding training'}</li>
                              <li>{lang === 'zh' ? '定期评估' : 'Regular assessments'}</li>
                              <li>{lang === 'zh' ? '晋升通道' : 'Promotion pathways'}</li>
                            </ul>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>

                  {/* Best Practices */}
                  <div className="space-y-4">
                    <h3 className="text-2xl font-bold">{lang === 'zh' ? '最佳实践' : 'Best Practices'}</h3>
                    <div className="grid md:grid-cols-2 gap-4">
                      <Card>
                        <CardHeader>
                          <CardTitle className="text-lg">{lang === 'zh' ? '沟通协作' : 'Communication & Collaboration'}</CardTitle>
                        </CardHeader>
                        <CardContent>
                          <ul className="text-sm space-y-2 text-muted-foreground">
                            <li>{lang === 'zh' ? '使用统一的协作工具（如Notion, Slack）' : 'Use unified collaboration tools (e.g., Notion, Slack)'}</li>
                            <li>{lang === 'zh' ? '每周例会制度化' : 'Weekly meetings institutionalized'}</li>
                            <li>{lang === 'zh' ? '建立问题升级机制' : 'Establish issue escalation mechanism'}</li>
                          </ul>
                        </CardContent>
                      </Card>
                      <Card>
                        <CardHeader>
                          <CardTitle className="text-lg">{lang === 'zh' ? '文档管理' : 'Document Management'}</CardTitle>
                        </CardHeader>
                        <CardContent>
                          <ul className="text-sm space-y-2 text-muted-foreground">
                            <li>{lang === 'zh' ? '所有文档集中存储' : 'All documents stored centrally'}</li>
                            <li>{lang === 'zh' ? '定期更新和维护' : 'Regular updates and maintenance'}</li>
                            <li>{lang === 'zh' ? '版本控制和审计追踪' : 'Version control and audit trail'}</li>
                          </ul>
                        </CardContent>
                      </Card>
                    </div>
                  </div>

                  {/* Quality Standards */}
                  <div className="bg-gradient-to-r from-primary/10 to-teal-500/10 rounded-lg p-8">
                    <h3 className="text-2xl font-bold mb-6">{lang === 'zh' ? '质量标准' : 'Quality Standards'}</h3>
                    <div className="grid md:grid-cols-3 gap-6">
                      <div>
                        <h4 className="font-semibold mb-3">{lang === 'zh' ? '活动质量' : 'Event Quality'}</h4>
                        <ul className="text-sm space-y-2 text-muted-foreground">
                          <li>{lang === 'zh' ? '参与者满意度>85%' : 'Participant satisfaction >85%'}</li>
                          <li>{lang === 'zh' ? '准时率>95%' : 'Punctuality >95%'}</li>
                          <li>{lang === 'zh' ? '目标达成率>90%' : 'Goal achievement >90%'}</li>
                        </ul>
                      </div>
                      <div>
                        <h4 className="font-semibold mb-3">{lang === 'zh' ? '成员服务' : 'Member Service'}</h4>
                        <ul className="text-sm space-y-2 text-muted-foreground">
                          <li>{lang === 'zh' ? '响应时间<24小时' : 'Response time <24 hours'}</li>
                          <li>{lang === 'zh' ? '问题解决率>90%' : 'Issue resolution rate >90%'}</li>
                          <li>{lang === 'zh' ? '活跃度保持>70%' : 'Activity retention >70%'}</li>
                        </ul>
                      </div>
                      <div>
                        <h4 className="font-semibold mb-3">{lang === 'zh' ? '组织健康' : 'Organization Health'}</h4>
                        <ul className="text-sm space-y-2 text-muted-foreground">
                          <li>{lang === 'zh' ? '成员留存率>80%' : 'Member retention rate >80%'}</li>
                          <li>{lang === 'zh' ? '财务透明度100%' : 'Financial transparency 100%'}</li>
                          <li>{lang === 'zh' ? '合规性达标100%' : 'Compliance 100%'}</li>
                        </ul>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>
          </Tabs>
        </div>
      </section>
    </div>
  );
}
