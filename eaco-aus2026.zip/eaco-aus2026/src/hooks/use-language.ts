'use client';

import { usePathname, useRouter } from 'next/navigation';
import { useCallback, useTransition } from 'react';
import type { Language } from '@/lib/i18n/translations';

export function useLanguage() {
  const router = useRouter();
  const pathname = usePathname();
  const [isPending, startTransition] = useTransition();

  const getCurrentLang = useCallback((): Language => {
    if (pathname.startsWith('/zh')) return 'zh';
    return 'en';
  }, [pathname]);

  const switchLanguage = useCallback((lang: Language) => {
    startTransition(() => {
      const currentLang = getCurrentLang();
      if (currentLang === lang) return;
      
      let newPath: string;
      if (lang === 'zh') {
        // Switch to Chinese
        if (pathname.startsWith('/en')) {
          newPath = pathname.replace('/en', '/zh');
        } else {
          newPath = '/zh' + pathname;
        }
      } else {
        // Switch to English
        if (pathname.startsWith('/zh')) {
          newPath = pathname.replace('/zh', '/en');
        } else {
          newPath = '/en' + pathname;
        }
      }
      
      router.push(newPath);
    });
  }, [getCurrentLang, pathname, router]);

  return {
    lang: getCurrentLang(),
    switchLanguage,
    isPending,
  };
}

export function getLangFromPathname(pathname: string): Language {
  if (pathname.startsWith('/zh')) return 'zh';
  return 'en';
}
